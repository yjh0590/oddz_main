const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
let currentRun = null;

async function status(text, title, color) {
  await Promise.all([
    chrome.action.setBadgeText({text}),
    chrome.action.setTitle({title}),
    chrome.action.setBadgeBackgroundColor({color})
  ]);
}

async function clean() {
  await status("…", "다운로드 파일 위치를 확인하고 있어요.", "#53657a");
  const completed = {state: "complete", limit: 0};
  const initial = await chrome.downloads.search(completed);
  if (initial.length) {
    // Chrome checks disk asynchronously and throttles checks to once per 10 s.
    await wait(10500);
    await chrome.downloads.search(completed);
    await wait(1800);
  }
  const gone = await chrome.downloads.erase({...completed, exists: false});
  const count = gone.length;
  await status(count > 999 ? "999+" : String(count),
    "이번에 정리한 다운로드 기록 " + count + "개", "#C93645");
  return count;
}

function start() {
  if (!currentRun) currentRun = clean().finally(() => { currentRun = null; });
  return currentRun;
}

chrome.action.onClicked.addListener(async () => {
  try { await start(); }
  catch (err) { await status("!", "정리 실패 · " + err.message, "#a43b30"); }
});

async function authorize(msg, sender) {
  const url = new URL(sender.url);
  if (sender.frameId !== 0 || url.protocol !== "http:" || url.hostname !== "127.0.0.1" ||
      !/^\/oddz-clean\/[a-f0-9]{48}$/.test(url.pathname) || url.search || url.hash ||
      msg?.task !== "clean" || !Number.isSafeInteger(msg.expires) ||
      msg.expires - Date.now()/1000 > 90 || msg.expires < Date.now()/1000 ||
      !/^[0-9a-f]{64}$/.test(msg.proof)) throw Error("앱에서 다시 실행해 주세요.");
  const res = await fetch(chrome.runtime.getURL("pair.json"), {cache:"no-store"});
  if (!res.ok) throw Error("앱의 ‘처음 연결’에서 도우미 폴더를 다시 확인해 주세요.");
  const bytes = hex => Uint8Array.from(hex.match(/../g), x => parseInt(x,16));
  const key = await crypto.subtle.importKey("raw",bytes(await res.json()), {name:"HMAC",hash:"SHA-256"},false,["verify"]);
  const valid = await crypto.subtle.verify("HMAC",key,bytes(msg.proof),new TextEncoder().encode(url.href+"|"+msg.expires));
  if (!valid) throw Error("현재 앱 폴더의 chrome-helper를 다시 등록해 주세요.");
}
chrome.runtime.onMessageExternal.addListener((msg,sender,reply) => {
  authorize(msg,sender).then(start)
    .then(count => reply({ok:true,count}), err => reply({ok:false,error:err.message}));
  return true;
});
