'use strict';
const $=s=>document.querySelector(s);
const menus=['파일 정리','정크 파일','폴더 용량','보관함','크롬 기록'];
const titles=['어떤 파일을 정리할까요?','오래된 임시 파일을 찾아볼까요?','어느 폴더가 가장 클까요?','어떤 파일을 되돌릴까요?','다운로드 기록을 정리할까요?'];
const subtitles=['폴더를 살펴보고 정리할 파일만 직접 골라요.','사용자 Temp와 선택한 폴더의 임시 파일·캐시를 확인해요.','폴더를 열어 안쪽에서 차지하는 용량까지 확인해요.','보관한 파일을 처음 있던 위치로 복원해요.','원래 경로에 파일이 없는 다운로드 완료 기록을 찾아요.'];
const paths=['M3 6h7l2 3h9v11H3z','M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14M10 10v7m4-7v7','M3 20h18M5 16v-4m6 4V7m6 9V3','M3 5h18v5H3zM5 11v9h14v-9m-10 2h6','M3 12a9 9 0 1 0 3-6M3 4v5h5m4-3v6l4 2','M8 3h8l4 4v14H8zM16 3v5h4M4 7v14','M4 12l5 5L20 6'];
const art='<svg class="art" aria-hidden="true" viewBox="0 0 150 120"><ellipse cx="76" cy="107" rx="56" ry="6" fill="#e5adb5"/><g transform="rotate(-8 76 71)"><path d="M19 34q0-6 7-6h31l10 11h54q7 0 7 7v51H19z" fill="#bd4a5a"/><rect x="35" y="21" width="66" height="66" rx="8" fill="#fff" transform="rotate(6 64 54)"/><path d="M46 39h40m-40 8h32" stroke="#e0b9bd" stroke-width="4" stroke-linecap="round"/><path d="M18 54q0-7 8-7h105q5 0 4 8l-9 42q-1 7-9 7H30q-8 0-9-8z" fill="#e77c88"/><path d="M37 61h31" stroke="#ffd2d9" stroke-width="4" stroke-linecap="round"/></g><path d="m124 12 3 8 8 3-8 3-3 8-3-8-8-3 8-3z" fill="#c44c61"/></svg>';
const icon=i=>'<svg aria-hidden="true" class="ico" viewBox="0 0 24 24"><path d="'+paths[i]+'"/></svg>';
const make=(tag,cls='',text='')=>{const x=document.createElement(tag);x.className=cls;x.textContent=text;return x};
function btn(parent,text,fn,cls=''){const x=make('button',cls,text);x.onclick=fn;x.disabled=busy;parent.append(x);return x}
function tile(i){const x=make('span','tile');x.innerHTML=icon(i);return x}
let state, page=0, filter='복사본',picked=new Set(),issues=new Map(),busy=false,rank=[],dir='',limit=80,checked=new Set();
const scope=()=>menus[page]+':'+filter;
const fmt=n=>{let i=0;while(n>=1024&&i<4){n/=1024;i++}return n.toLocaleString('ko-KR',{maximumFractionDigits:i?1:0})+' '+['B','KB','MB','GB','TB'][i]};
const rows=()=>page===0?state.files.filter(r=>r.kind===filter):page===1?state.junk:page===2?rank:page===3?state.stash:[];
const marked=()=>rows().filter(r=>picked.has(r.id));
function say(s){$('#status').textContent=s}
async function api(action,data={}){
 const r=await fetch('api/'+action,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
 const result=await r.json();if(!r.ok)throw Error(result.error||'앱을 다시 실행해 주세요.');return result
}
function lock(on){busy=on;document.body.classList.toggle('busy',on);for(const e of document.querySelectorAll('button,input:not(#reduce)'))e.disabled=on}
async function work(fn){if(busy)return;lock(true);try{await fn()}catch(e){say(e.message)}finally{lock(false);render()}}
async function modal(title,detail,action){
 const d=$('dialog');$('#dialogTitle').textContent=title;$('#dialogDesc').textContent=detail;
 const a=$('#dialogBtns');a.replaceChildren();const no=btn(a,'닫기',()=>d.close('no'));if(action)btn(a,action,()=>d.close('yes'),'primary');
 d.returnValue='';d.showModal();no.focus();
 return new Promise(resolve=>d.addEventListener('close',()=>resolve(d.returnValue==='yes'),{once:true}))
}
function motionOff(){return $('#reduce').checked||matchMedia('(prefers-reduced-motion: reduce)').matches}
$('#reduce').checked=localStorage.getItem('reduce')==='1';$('#reduce').onchange=()=>{localStorage.setItem('reduce',$('#reduce').checked?'1':'0')};
async function scan(pick=false){await work(async()=>{
 say('폴더를 확인하고 있어요…');const old=state.root;
 const v=await api('scan',{pick,mode:page===1?'junk':'files'});if(v.cancel){say('폴더 선택을 취소했어요.');return}state=v;dir=v.root;
 if(old!==v.root)checked.clear();checked.add(page===1?'junk':'files');picked.clear();issues.clear();
 if(page===2)rank=await api('rank',{path:dir});say('검사가 끝났어요.'+(v.logs.length?'  확인할 항목 '+v.logs.length+'개':''))})}
async function switchTo(i){if(busy)return;await work(async()=>{page=i;picked.clear();limit=80;say('');if(i===2){dir=state.root;rank=await api('rank',{path:dir})}})}
function render(){
 if(!state)return;
 const nav=$('nav');nav.replaceChildren();menus.forEach((n,i)=>{const b=btn(nav,'',()=>switchTo(i),'navbtn'+(i===page?' active':''));b.innerHTML=icon(i);b.append(document.createTextNode(n));if(i===page)b.setAttribute('aria-current','page')});
 $('#crumb').textContent=menus[page];$('#title').textContent=titles[page];$('#sub').textContent=subtitles[page];
 const hero=$('#hero');hero.replaceChildren();hero.insertAdjacentHTML('beforeend',art);
 const h=make('div','hero-copy'),heading=page===4?'다운로드 목록만 가볍게':page===1?'오래된 임시 파일 검사':state.root?(state.root.split(/[\\/]/).pop()||state.root):'정리할 폴더를 골라 주세요';
 h.append(make('h2','',heading),make('p','',page===4?'기록을 지워도 컴퓨터의 실제 파일은 그대로예요.':page===1?'7일 이상 지난 임시 파일과 확인 가능한 캐시를 찾아요.':state.root||'다운로드, 바탕 화면, 문서 중 한 곳부터 시작해요.'));hero.append(h);
 if(page===4){btn(h,'기록 지우기',clearChrome,'primary')}
 else{btn(h,page===1?'정크 파일 찾기':state.root?'다시 검사하기':'폴더 선택하기',()=>scan(false),picked.size?'':'primary');if(state.root||page===1)btn(h,'다른 폴더 선택',()=>scan(true))}
 const items=rows(),tools=$('#tools'),filters=$('#filters');tools.replaceChildren();filters.replaceChildren();
 $('#section').textContent=page===4?'크롬 연결':page===2?'폴더별 사용량':page===3?'보관한 파일':(!state.root&&page===0?'이런 파일을 찾을 수 있어요':'검사 결과');
 if(page===0&&state.root)for(const f of state.filters){const b=btn(filters,f,()=>{filter=f;picked.clear();limit=80;say('');render()},'chip'+(f===filter?' on':''));b.setAttribute('aria-pressed',String(filter===f))}
 if(page!==2&&items.length&&filterAllowed())btn(tools,picked.size?'선택 해제':'전체 선택',()=>{picked=picked.size?new Set():new Set(items.map(r=>r.id));render()});
 if(page===2&&dir&&dir!==state.root)btn(tools,'상위 폴더',()=>enter(dir.slice(0,dir.lastIndexOf('\\'))||state.root));
 if(state.logs.length)btn(tools,'검사 기록',()=>modal('검사 기록',state.logs.slice(0,30).join('\n')));
 const list=$('#list');list.replaceChildren();
 if(page===4){guide(4,'연결 도우미 등록','처음 한 번, 사용하는 크롬 프로필에 연결해 주세요.');btn(list,'도우미 등록하기',()=>work(async()=>{const v=await api('setup');try{await navigator.clipboard.writeText(v.path)}catch{}say('크롬의 개발자 모드 → 압축해제된 확장 프로그램 로드 → '+v.path)}));}
 else if(!state.root&&page===0){guide(5,'복사본','이름이 달라도 내용이 같은 파일을 찾아요.');guide(3,'풀어둔 ZIP','압축을 푼 폴더에 모든 파일이 있는지 비교해요.');guide(0,'작업 버전','초안과 최종본을 같은 묶음에서 살펴봐요.')}
 else if(!items.length){list.append(make('p','blank',page===1&&!checked.has('junk')?'정크 파일 찾기를 눌러 검사를 시작하세요.':page===3?'보관한 파일이 여기에 표시돼요.':page===2?'검사하면 폴더별 용량을 볼 수 있어요.':'현재 분류에 표시할 파일이 없어요.'))}
 else{
 let group='';const ordered=items.slice();if(page===0&&['작업 버전','변환 파일'].includes(filter))ordered.sort((a,b)=>a.group.localeCompare(b.group,'ko')||b.size-a.size);else ordered.sort((a,b)=>b.size-a.size);
 for(const r of ordered.slice(0,limit)){
 if(r.group&&r.group!==group){group=r.group;list.append(make('h3','group',group.split(/[\\/]/).pop()))}
 const row=make('div','row'+(picked.has(r.id)?' selected':''));if(r.id)row.dataset.id=r.id;
 if(page!==2&&filterAllowed()){let box=make('input');box.type='checkbox';box.checked=picked.has(r.id);box.setAttribute('aria-label',r.name+' 선택');box.onchange=()=>{if(box.checked)picked.add(r.id);else picked.delete(r.id);row.classList.toggle('selected',box.checked);render()};row.onclick=e=>{if(!busy&&e.target!==box)box.click()};row.append(box)}
 else{row.append(tile(r.folder?0:5));row.tabIndex=0;row.onclick=()=>r.folder?enter(r.path):reveal(r.path);row.onkeydown=e=>{if(e.key==='Enter')row.click()}}
 const t=make('div','text'),p=make('small','',r.path);p.title=r.path;t.append(make('b','',r.name),p);
 const problem=issues.get(r.path);t.append(make('em',problem?'error':'',problem||[r.note,r.date,r.folder?r.count+'개 파일':''].filter(Boolean).join(' · ')));row.append(t,make('div','amount',fmt(r.size)));list.append(row)
 }
 if(limit<items.length)btn(list,'다음 80개 보기',()=>{limit+=80;render()},'more')
 }
 footer()
}
function filterAllowed(){return page!==0||filter!=='ZIP 확인'}
function guide(i,n,s){const g=make('div','guide'),t=make('div','text');t.append(make('b','',n),make('small','',s));g.append(tile(i),t);$('#list').append(g)}
function footer(){const a=$('#actionbar');a.replaceChildren();const m=marked();if(!m.length||page===2)return;
 a.append(make('b','',m.length.toLocaleString()+'개 선택 · '+fmt(m.reduce((s,r)=>s+r.size,0))));
 if(m.length===1){btn(a,'파일 위치',()=>reveal(m[0].reveal||m[0].path));if(m[0].compare)btn(a,'비교 위치',()=>reveal(m[0].compare))}
 if(page===0)btn(a,'보관함으로 이동',()=>apply('stash'));btn(a,page===3?'원래 위치로 복원':'휴지통으로 이동',()=>apply(page===3?'restore':'trash'),'primary')}
function reveal(path){return work(()=>api('reveal',{path}))}
function enter(path){return work(async()=>{rank=await api('rank',{path});dir=path;limit=80})}
async function clearChrome(){if(!await modal('다운로드 기록을 지울까요?','현재 프로필에서 원래 경로에 파일이 없는 완료 기록만 지워요.','기록 지우기'))return;await work(async()=>{say('크롬에서 확인 중이에요.');const v=await api('chrome');say('다운로드 기록 '+v.count+'개를 지웠어요.')})}
async function apply(op){
 const m=marked(),label={trash:'휴지통으로 이동',restore:'원래 위치로 복원',stash:'보관함으로 이동'}[op];if(!m.length)return;
 if(!await modal(label+'할까요?',m.length+'개 · '+fmt(m.reduce((s,r)=>s+r.size,0))+'\n'+({trash:'Windows 휴지통에서 복원할 수 있어요.',restore:'기존 파일과 충돌하면 건너뛰어요.',stash:'앱 보관함에서 되돌릴 수 있어요.'})[op],label))return;
 await work(async()=>{const selected=[...document.querySelectorAll('.row.selected')].filter(el=>{let b=el.getBoundingClientRect();return b.bottom>0&&b.top<innerHeight});const anim=op==='trash'&&!motionOff();const anims=[];
 try{
 if(anim&&selected.length){let end=Math.min(innerHeight,$('#list').getBoundingClientRect().bottom)-54;selected.forEach((el,i)=>{el.style.zIndex='1';const dy=Math.max(0,end-el.getBoundingClientRect().top-i*2);anims.push(el.animate([{transform:'none'},{transform:'translateY('+dy+'px)'}],{duration:290,easing:'ease-out',fill:'forwards'}))});await Promise.all(anims.map(a=>a.finished))}
 say('파일 상태를 확인하고 있어요…');const v=await api('apply',{ids:m.map(r=>r.id),op});
 if(anim&&!motionOff()){const next=selected.map(el=>{let t=getComputedStyle(el).transform;return el.animate([{transform:t},{transform:v.ok.includes(el.dataset.id)?'translateX(110%) '+(t==='none'?'':t):'none'}],{duration:270,easing:'ease-in',fill:'forwards'})});anims.push(...next);await Promise.all(next.map(a=>a.finished))}
 state=v.state;const failed=new Set();for(const r of m){if(v.errors[r.id]){issues.set(r.path,v.errors[r.id]+' · 파일 위치를 확인한 뒤 다시 시도하세요.');failed.add(r.path)}else issues.delete(r.path)}
 picked=new Set(rows().filter(r=>failed.has(r.path)).map(r=>r.id));say(label+' '+v.ok.length+'개 · 실패 '+failed.size+'개')
 }finally{anims.forEach(a=>a.cancel())}})}
api('init').then(v=>{state=v;render()}).catch(e=>say(e.message));setInterval(()=>fetch('api/ping',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}).catch(()=>{}),15000);
