"""Serve the desktop renderer on a private, short-lived loopback address."""
import ctypes
import json
import os
import secrets
import subprocess
import sys
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

BASE=Path(__file__).resolve().parent
def start():
    import tkinter as tk
    from tkinter import filedialog
    import chrome_link, junk, desk
    from engine import held, newbatch, relocate, scan, signature, stage, validate_row
    from recycle import recycle
    from organizer import FILTERS
    try:
        chrome = chrome_link.find_chrome()
    except FileNotFoundError:
        from organizer import App
        desk.load_typeface()
        win=tk.Tk();App(win);win.mainloop();return
    root=None; rows=[];stash=[];index=[]; junks=[]; logs=[]; refs={};token=secrets.token_urlsafe(32)
    def pack(p,n,reason,kind,obj,group=None):
        key=secrets.token_hex(10)
        refs[key]=(kind,obj)
        return dict(id=key,path=str(p),name=p.name,size=n,note=reason,kind=kind,group=str(group or ''))
    def collect(kind):
        nonlocal root,rows,stash,index,junks,logs
        if kind=='junk':
            junks,logs=junk.collect(root,junk.user_temp())
        else:
            index=[]
            rows,_,logs=scan(root,folder_data=index)
            stash=held(root)
    def snapshot():
        refs.clear()
        files=[pack(r.path,r.size,r.detail,r.kind,r,r.group) | {'compare':str(r.keep or ''),'date':time.strftime('%Y.%m.%d',time.localtime(r.stamp[1]/1e9))} for r in rows]
        temp=[pack(r.path,r.stamp[0],r.reason,'정크 파일',r) for r in junks]
        saved=[]
        for p,d in stash:
            try:saved.append(pack(d,p.stat().st_size,'원래 위치로 복원할 수 있어요.','보관함',(p,d)) | {'reveal':str(p)})
            except OSError:pass
        return dict(root=str(root or ''),files=files,junk=temp,stash=saved,logs=logs,temp=str(junk.user_temp() or ''),filters=FILTERS)
    def dispatch(a,v):
        nonlocal root,rows,stash,index,junks
        if a=='init':return snapshot()
        if a=='scan':
            if v.get('pick') or (root is None and v['mode']!='junk'):
                win=tk.Tk();win.withdraw();win.attributes('-topmost',True)
                try:chosen=filedialog.askdirectory(parent=win,initialdir=root or Path.home())
                finally:win.destroy()
                if not chosen:return {'cancel':True}
                target=Path(chosen).absolute()
                if target!=root:
                    rows=[];junks=[];index=[];stash=[];refs.clear()
                root=target
            collect(v['mode']);return snapshot()
        if a=='rank':
            if not index:return []
            ch,di,tot=index[0];p=Path(v['path']) if v.get('path') else root
            if p not in ch:return []
            return sorted([dict(path=str(d),name=d.name,size=tot[d][0],count=tot[d][1],folder=True) for d in ch[p]]+
                          [dict(path=str(f),name=f.name,size=n,folder=False) for f,n in di[p]],key=lambda r:-r['size'])
        if a=='reveal':
            p=Path(v['path'])
            if not root or not p.is_relative_to(root):
                if not any(r.path==p for r in junks):raise ValueError('검사한 파일을 골라 주세요.')
            if not p.exists():raise ValueError('원래 위치에 파일이 없어요. 다시 검사해 주세요.')
            subprocess.Popen(['explorer.exe','/select,',str(p)]);return {}
        if a=='setup':
            chrome_link.pairing_key();chrome_link.launch('chrome://extensions/')
            return {'path':str(chrome_link.HELPER)}
        if a=='chrome':return {'count':chrome_link.run_cleanup()}
        if a!='apply':raise ValueError('작업을 찾지 못했어요.')
        ids=list(dict.fromkeys(v['ids']));op=v['op']
        if op not in ('trash','stash','restore') or not ids or any(k not in refs for k in ids):raise ValueError('목록을 다시 확인해 주세요.')
        kinds={refs[k][0] for k in ids}
        if len(kinds)!=1 or ('보관함' in kinds)!=(op=='restore') or ('정크 파일' in kinds and op!='trash') or 'ZIP 확인' in kinds:raise ValueError('같은 종류의 파일을 선택해 주세요.')
        selected=[refs[k][1] for k in ids];paths={r.path for r in selected} if op!='restore' else set()
        keep={r.group:r.path for r in rows if r.group and r.kind in kinds and r.path not in paths and r.path.is_file()}
        ok=[];errors={};batch=newbatch()
        for key,obj in zip(ids,selected):
            try:
                if op=='restore':relocate(root,*obj)
                elif '정크 파일' in kinds:
                    if not junk.allowed(obj.root,obj.path) or signature(obj.path)!=obj.stamp or junk.reason(obj.path,obj.stamp,junk.user_temp())!=obj.reason:raise ValueError('검사 후 바뀐 파일이에요. 다시 검사해 주세요.')
                    recycle(obj.path)
                else:
                    if obj.group:
                        if obj.group not in keep:raise ValueError('이 묶음에서 남길 파일 하나를 선택 해제하세요.')
                        obj=obj._replace(keep=keep[obj.group])
                    if op=='stash':stage(root,obj,batch)
                    else:validate_row(root,obj);recycle(obj.path)
                ok.append(key)
            except Exception as e:errors[key]=str(e)
        gone={refs[k][1].path for k in ok} if op!='restore' else set()
        rows=[r for r in rows if r.path not in gone];junks=[r for r in junks if r.path not in gone]
        if ok:index=[]
        if root:
            try:stash=held(root)
            except OSError as e:logs.append(str(e))
        return dict(ok=ok,errors=errors,state=snapshot())
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def response(self,code,data,typ):
            self.send_response(code);self.send_header('Content-Type',typ);self.send_header('Cache-Control','no-store');self.send_header('Referrer-Policy','no-referrer');self.send_header('X-Frame-Options','DENY');self.send_header('Content-Length',str(len(data)));self.end_headers()
            try:self.wfile.write(data)
            except (BrokenPipeError,ConnectionResetError):pass
        def do_GET(self):
            name=self.path.removeprefix('/'+token+'/')
            assets={'':'index.html','style.css':'style.css','ui.js':'ui.js','icon.ico':'Sseuk-Ssak.ico','mark.png':'mark.png','font.ttf':'fonts/SseukSsakDance.ttf'}
            if self.headers.get('Host')!=host or not self.path.startswith('/'+token+'/') or name not in assets:return self.send_error(404)
            typ={'':'text/html; charset=utf-8','style.css':'text/css','ui.js':'text/javascript','font.ttf':'font/ttf','mark.png':'image/png','icon.ico':'image/x-icon'}[name]
            self.response(200,(BASE/assets[name]).read_bytes(),typ)
        def do_POST(self):
            if self.headers.get('Origin')!=origin or self.headers.get('Host')!=host or not self.path.startswith('/'+token+'/api/'):return self.send_error(403)
            try:
                n=int(self.headers.get('Content-Length',0))
                if not 0<=n<=8000000:raise ValueError('요청이 너무 커요.')
                v=json.loads(self.rfile.read(n));action=self.path.rsplit('/',1)[1]
                result={} if action=='ping' else dispatch(action,v)
                self.response(200,json.dumps(result).encode(),'application/json')
            except Exception as e:self.response(400,json.dumps({'error':str(e)}).encode(),'application/json')
    with HTTPServer(('127.0.0.1',0),Handler) as server:
        host=f'127.0.0.1:{server.server_port}';origin='http://'+host;server.timeout=3
        subprocess.Popen([str(chrome),'--app='+origin+'/'+token+'/'])
        last=time.monotonic()
        import select
        while time.monotonic()-last<180:
            if select.select([server],[],[],3)[0]:
                server.handle_request();last=time.monotonic()
if __name__=='__main__':
    try:
        if sys.version_info<(3,9):raise RuntimeError('Python 3.9 이상이 필요해요.')
        start()
    except Exception as e:ctypes.windll.user32.MessageBoxW(None,str(e),'쓱-싹 실행 안내',16)
