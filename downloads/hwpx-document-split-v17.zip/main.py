from __future__ import annotations

import argparse
import csv
import html
import io
import os
import re
import shutil
import struct
import sys
import tempfile
import zipfile
import zlib
import xml.etree.ElementTree as ET
from collections import Counter
from copy import deepcopy
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import xlrd
from xlrd.compdoc import CompDoc


APP_NAME = "사업별 HWPX 분할 도구 v17"
END_MARKER_TEXT = "5. 기타 추가자료"
BANNER_TEXT = "Ⅴ. 근로복지진흥기금"
PAGE_BREAK_HEADINGS = (
    "2. 지출계획 총괄표",
    "3. 사업 설명",
    "4. 최근 4년간",
    "5. 기타 추가자료",
)
PLACEHOLDER_TEXTS = (
    "해당 세부사업 설명자료는 비공개 자료입니다.",
    "비공개 자료입니다",
)
TITLE_RE = re.compile(r"^\((\d+)\)\s*(.*?)\s*\((\d{4})\s*-\s*(\d{3})\)\s*$")
HWPX_SECTION_RE = re.compile(r"^Contents/section(\d+)\.xml$", re.IGNORECASE)
NAMED_OUTPUT_FOLDER = "사업명_파일"
CODE_OUTPUT_FOLDER = "코드명_파일"
HPF_NAMESPACES = (
    ("ha", "http://www.hancom.co.kr/hwpml/2011/app"),
    ("hp", "http://www.hancom.co.kr/hwpml/2011/paragraph"),
    ("hp10", "http://www.hancom.co.kr/hwpml/2016/paragraph"),
    ("hs", "http://www.hancom.co.kr/hwpml/2011/section"),
    ("hc", "http://www.hancom.co.kr/hwpml/2011/core"),
    ("hh", "http://www.hancom.co.kr/hwpml/2011/head"),
    ("hhs", "http://www.hancom.co.kr/hwpml/2011/history"),
    ("hm", "http://www.hancom.co.kr/hwpml/2011/master-page"),
    ("hpf", "http://www.hancom.co.kr/schema/2011/hpf"),
    ("dc", "http://purl.org/dc/elements/1.1/"),
    ("opf", "http://www.idpf.org/2007/opf/"),
    ("ooxmlchart", "http://www.hancom.co.kr/hwpml/2016/ooxmlchart"),
    ("hwpunitchar", "http://www.hancom.co.kr/hwpml/2016/HwpUnitChar"),
    ("epub", "http://www.idpf.org/2007/ops"),
    ("config", "urn:oasis:names:tc:opendocument:xmlns:config:1.0"),
)


@dataclass
class SectionInfo:
    index: int
    full_title: str
    project_name: str
    unit_code: str
    detail_code: str
    body_text: str

    @property
    def code_suffix(self) -> str:
        return self.unit_code + self.detail_code


@dataclass
class ExcelRow:
    row_number: int
    department: str
    project_name: str
    file_code: str


@dataclass
class WorkItem:
    row_number: int
    department: str
    file_code: str
    excel_project_name: str
    template_path: str
    section_index: int | None
    source_title: str
    next_title: str
    status: str
    reason: str
    output_path: str = ""
    named_output_path: str = ""
    appendix_markers: str = ""


def normalize_name(value: Any) -> str:
    text = "" if value is None else str(value)
    return re.sub(r"[^0-9A-Za-z가-힣]", "", text).casefold()


def split_trailing_qualifier(value: str) -> tuple[str, str]:
    """Return `base name`, `final parenthetical qualifier` when present."""
    match = re.match(r"^(.*?)\s*\(([^()]*)\)\s*$", value.strip())
    if not match:
        return value.strip(), ""
    return match.group(1).strip(), match.group(2).strip()


def project_name_matches_text(project_name: str, document_text: str) -> bool:
    """Apply the same base-name/qualifier rule used during preflight."""
    normalized_text = normalize_name(document_text)
    if normalize_name(project_name) in normalized_text:
        return True
    base_name, qualifier = split_trailing_qualifier(project_name)
    return (
        bool(qualifier)
        and normalize_name(base_name) in normalized_text
        and normalize_name(qualifier) in normalized_text
    )


def end_marker_count(document_text: str) -> int:
    return normalize_name(document_text).count(normalize_name(END_MARKER_TEXT))


def appendix_markers_after_end_heading(document_text: str) -> list[str]:
    marker_position = document_text.find(END_MARKER_TEXT)
    if marker_position < 0:
        return []
    tail = document_text[marker_position + len(END_MARKER_TEXT):]
    numbers = sorted({int(value) for value in re.findall(r"참고\s*(\d+)", tail)})
    return [f"참고 {number}" for number in numbers]


def clean_cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def detect_document_type(path: Path) -> str:
    head = path.read_bytes()[:32]
    if head.startswith(b"PK"):
        return "HWPX"
    if head.startswith(bytes.fromhex("D0CF11E0A1B11AE1")):
        return "HWP5"
    return "UNKNOWN"


def _read_hwp_stream(path: Path, stream_name: str) -> bytes:
    doc = CompDoc(path.read_bytes(), logfile=io.StringIO())
    stream = doc.get_named_stream(stream_name)
    if stream is None:
        raise KeyError(stream_name)
    return stream


def _paragraph_texts(stream: bytes, compressed: bool = True) -> list[str]:
    raw = zlib.decompress(stream, -15) if compressed else stream
    pos = 0
    texts: list[str] = []
    while pos + 4 <= len(raw):
        header = struct.unpack_from("<I", raw, pos)[0]
        pos += 4
        tag_id = header & 0x3FF
        size = (header >> 20) & 0xFFF
        if size == 0xFFF:
            if pos + 4 > len(raw):
                break
            size = struct.unpack_from("<I", raw, pos)[0]
            pos += 4
        payload = raw[pos:pos + size]
        pos += size
        if tag_id != 67:  # HWPTAG_PARA_TEXT
            continue
        decoded = payload.decode("utf-16le", errors="ignore")
        decoded = "".join(ch if ord(ch) >= 32 else " " for ch in decoded)
        decoded = re.sub(r"\s+", " ", decoded).strip()
        if decoded:
            texts.append(decoded)
    return texts


def analyze_hwp_sections(path: Path) -> list[SectionInfo]:
    if detect_document_type(path) != "HWP5":
        raise ValueError("통합문서는 현재 샘플과 같은 HWP 5.0 형식이어야 합니다.")
    doc = CompDoc(path.read_bytes(), logfile=io.StringIO())
    file_header = doc.get_named_stream("FileHeader")
    if file_header is None or len(file_header) < 40:
        raise ValueError("HWP 파일 헤더를 읽지 못했습니다.")
    compressed = bool(struct.unpack_from("<I", file_header, 36)[0] & 1)
    sections: list[SectionInfo] = []
    index = 0
    while True:
        try:
            stream = doc.get_named_stream(f"BodyText/Section{index}")
        except Exception:
            break
        if stream is None:
            break
        texts = _paragraph_texts(stream, compressed=compressed)
        matches = []
        for text in texts:
            match = TITLE_RE.match(text)
            if match:
                matches.append((text, match))
        if len(matches) != 1:
            raise ValueError(
                f"Section{index}에서 사업 제목을 {len(matches)}개 발견했습니다. "
                "자동 분할하지 말고 문서를 확인하세요."
            )
        full_title, match = matches[0]
        sections.append(SectionInfo(
            index=index,
            full_title=full_title,
            project_name=match.group(2).strip(),
            unit_code=match.group(3),
            detail_code=match.group(4),
            body_text=" ".join(texts),
        ))
        index += 1
    if not sections:
        raise ValueError("통합문서에서 사업별 Section을 찾지 못했습니다.")
    return sections


def _hwpx_paragraph_texts(data: bytes) -> list[str]:
    """Return visible text grouped by HWPX paragraph."""
    root = ET.fromstring(data)
    texts: list[str] = []
    for element in root.iter():
        if element.tag.rsplit("}", 1)[-1] != "p":
            continue
        chunks = [
            child.text or ""
            for child in element.iter()
            if child.tag.rsplit("}", 1)[-1] == "t"
        ]
        text = re.sub(r"\s+", " ", "".join(chunks)).strip()
        if text:
            texts.append(text)
    return texts


def analyze_hwpx_sections(path: Path) -> list[SectionInfo]:
    """Read titles and body text from a genuine ZIP/XML HWPX document."""
    if detect_document_type(path) != "HWPX":
        raise ValueError("통합문서가 실제 HWPX 형식이 아닙니다.")
    sections: list[SectionInfo] = []
    with zipfile.ZipFile(path) as archive:
        section_paths = sorted(
            (
                (int(match.group(1)), name)
                for name in archive.namelist()
                if (match := HWPX_SECTION_RE.match(name))
            ),
            key=lambda item: item[0],
        )
        for index, section_path in section_paths:
            texts = _hwpx_paragraph_texts(archive.read(section_path))
            matches = []
            for text in texts:
                match = TITLE_RE.match(text)
                if match:
                    matches.append((text, match))
            if len(matches) != 1:
                raise ValueError(
                    f"HWPX Section{index}에서 사업 제목을 {len(matches)}개 발견했습니다. "
                    "자동 분할하지 말고 문서를 확인하세요."
                )
            full_title, match = matches[0]
            sections.append(SectionInfo(
                index=index,
                full_title=full_title,
                project_name=match.group(2).strip(),
                unit_code=match.group(3),
                detail_code=match.group(4),
                body_text=" ".join(texts),
            ))
    if not sections:
        raise ValueError("통합 HWPX에서 사업별 Section을 찾지 못했습니다.")
    return sections


def analyze_document_sections(path: Path) -> list[SectionInfo]:
    document_type = detect_document_type(path)
    if document_type == "HWP5":
        return analyze_hwp_sections(path)
    if document_type == "HWPX":
        return analyze_hwpx_sections(path)
    raise ValueError("통합문서가 HWP 5.0 또는 HWPX 형식이 아닙니다.")


def read_excel_rows(path: Path, sheet_name: str = "확인자료") -> tuple[list[str], list[ExcelRow]]:
    book = xlrd.open_workbook(path, formatting_info=False)
    if sheet_name not in book.sheet_names():
        raise ValueError(f"엑셀에 '{sheet_name}' 시트가 없습니다.")
    sheet = book.sheet_by_name(sheet_name)
    headers = [clean_cell(sheet.cell_value(0, col)) for col in range(sheet.ncols)]
    required = ["소관명", "세부사업명", "파일명", "작업일", "작업자", "상태", "비고", "완료여부"]
    missing = [name for name in required if name not in headers]
    if missing:
        raise ValueError("엑셀 필수 열이 없습니다: " + ", ".join(missing))
    pos = {name: headers.index(name) for name in headers}
    rows: list[ExcelRow] = []
    for row in range(1, sheet.nrows):
        file_code = clean_cell(sheet.cell_value(row, pos["파일명"]))
        if not file_code:
            continue
        rows.append(ExcelRow(
            row_number=row + 1,
            department=clean_cell(sheet.cell_value(row, pos["소관명"])),
            project_name=clean_cell(sheet.cell_value(row, pos["세부사업명"])),
            file_code=file_code,
        ))
    return headers, rows


def collect_templates(folder: Path) -> list[Path]:
    return sorted(path for path in folder.rglob("*.hwpx") if path.is_file())


def safe_windows_filename(value: str, fallback: str, max_length: int = 120) -> str:
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value).strip().rstrip(".")
    value = re.sub(r"\s+", " ", value)
    if not value:
        value = fallback
    reserved = {"CON", "PRN", "AUX", "NUL", *(f"COM{x}" for x in range(1, 10)), *(f"LPT{x}" for x in range(1, 10))}
    if value.upper() in reserved:
        value = "_" + value
    return value[:max_length].rstrip(" .") or fallback


def assign_named_output_paths(items: list[WorkItem], output_folder: Path) -> None:
    names = [safe_windows_filename(x.excel_project_name, x.file_code) for x in items if x.excel_project_name]
    counts = Counter(name.casefold() for name in names)
    for item in items:
        if not item.excel_project_name:
            continue
        name = safe_windows_filename(item.excel_project_name, item.file_code)
        if counts[name.casefold()] > 1:
            name = safe_windows_filename(f"{name}_{item.file_code}", item.file_code)
        item.named_output_path = str(output_folder / NAMED_OUTPUT_FOLDER / f"{name}.hwpx")


def build_work_plan(template_folder: Path, integrated_path: Path, excel_path: Path, output_folder: Path) -> tuple[list[WorkItem], list[str]]:
    sections = analyze_document_sections(integrated_path)
    _, rows = read_excel_rows(excel_path)
    templates = collect_templates(template_folder)
    if not templates:
        raise ValueError("첨부폴더 1에서 HWPX 파일을 찾지 못했습니다.")

    excel_by_code: dict[str, list[ExcelRow]] = {}
    for row in rows:
        excel_by_code.setdefault(row.file_code.casefold(), []).append(row)
    section_by_suffix: dict[str, list[SectionInfo]] = {}
    section_by_name: dict[str, list[SectionInfo]] = {}
    for section in sections:
        section_by_suffix.setdefault(section.code_suffix, []).append(section)
        section_by_name.setdefault(normalize_name(section.project_name), []).append(section)

    warnings: list[str] = []
    items: list[WorkItem] = []
    used_sections: set[int] = set()
    for template in templates:
        file_code = template.stem.strip()
        row_candidates = excel_by_code.get(file_code.casefold(), [])
        rel = template.relative_to(template_folder)
        output_path = output_folder / CODE_OUTPUT_FOLDER / rel
        if len(row_candidates) != 1:
            reason = "엑셀에 동일 파일명이 여러 행 있음" if row_candidates else "엑셀에서 파일명을 찾지 못함"
            items.append(WorkItem(0, "", file_code, "", str(template), None, "", "", "확인필요", reason, str(output_path)))
            continue
        row = row_candidates[0]
        suffix_candidates = [s for suffix, values in section_by_suffix.items() if file_code.endswith(suffix) for s in values]
        name_candidates = section_by_name.get(normalize_name(row.project_name), [])
        both = [s for s in suffix_candidates if s in name_candidates]
        chosen: SectionInfo | None = None
        status = "확인필요"
        reason = ""
        if len(both) == 1:
            chosen = both[0]
            status = "처리가능"
            reason = "파일코드 끝자리와 세부사업명이 모두 일치"
        elif len(suffix_candidates) == 1:
            code_match = suffix_candidates[0]
            base_name, qualifier = split_trailing_qualifier(row.project_name)
            qualifier_matches_context = (
                bool(qualifier)
                and normalize_name(base_name) == normalize_name(code_match.project_name)
                and normalize_name(qualifier) in normalize_name(code_match.body_text)
            )
            if qualifier_matches_context:
                chosen = code_match
                status = "처리가능"
                reason = "사업코드·기본 사업명·괄호 구분명이 Section 본문과 일치"
            elif not name_candidates:
                chosen = code_match
                reason = "사업코드는 일치하지만 세부사업명이 다름"
            else:
                reason = "사업코드는 일치하지만 세부사업명 후보를 확정하지 못함"
        elif len(name_candidates) == 1 and not suffix_candidates:
            chosen = name_candidates[0]
            reason = "세부사업명은 일치하지만 사업코드가 다름"
        elif len(both) > 1 or len(suffix_candidates) > 1 or len(name_candidates) > 1:
            reason = "통합문서에 대응 후보가 여러 개 있음"
        else:
            reason = "통합문서에서 대응 Section을 찾지 못함"

        next_title = ""
        appendix_markers = ""
        if chosen is not None:
            used_sections.add(chosen.index)
            if chosen.index + 1 < len(sections):
                next_title = sections[chosen.index + 1].full_title
            marker_count = end_marker_count(chosen.body_text)
            if status == "처리가능" and marker_count != 1:
                status = "확인필요"
                reason = (
                    f"문서 사업 범위의 '{END_MARKER_TEXT}' 문구가 {marker_count}개라 "
                    "자동 분할할 수 없음"
                )
            appendix_markers = "|".join(appendix_markers_after_end_heading(chosen.body_text))
        items.append(WorkItem(
            row_number=row.row_number,
            department=row.department,
            file_code=file_code,
            excel_project_name=row.project_name,
            template_path=str(template),
            section_index=chosen.index if chosen else None,
            source_title=chosen.full_title if chosen else "",
            next_title=next_title,
            status=status,
            reason=reason,
            output_path=str(output_path),
            appendix_markers=appendix_markers,
        ))

    unused = [s for s in sections if s.index not in used_sections]
    if unused:
        warnings.append(f"통합문서 Section {len(unused)}개는 첨부폴더 1의 샘플 파일과 연결되지 않았습니다.")
    duplicate_sections: dict[int, int] = {}
    for item in items:
        if item.section_index is not None:
            duplicate_sections[item.section_index] = duplicate_sections.get(item.section_index, 0) + 1
    for section_index, count in duplicate_sections.items():
        if count > 1:
            for item in items:
                if item.section_index == section_index:
                    item.status = "확인필요"
                    item.reason = f"같은 Section이 템플릿 {count}개에 연결됨"
    assign_named_output_paths(items, output_folder)
    return items, warnings


def _dispatch_hwp(visible: bool):
    if os.name != "nt":
        raise RuntimeError("실제 HWPX 분할은 한컴오피스가 설치된 Windows에서만 실행할 수 있습니다.")
    try:
        import win32com.client
    except ImportError as exc:
        raise RuntimeError("pywin32가 설치되지 않았습니다. run.bat을 다시 실행하세요.") from exc
    hwp = win32com.client.gencache.EnsureDispatch("HWPFrame.HwpObject")
    try:
        hwp.XHwpWindows.Item(0).Visible = visible
    except Exception:
        pass
    # 한컴 공식 예제 모듈명과 기존 배포판에서 쓰인 이름을 모두 시도한다.
    # 보안 모듈이 설치되지 않은 PC에서도 통합문서는 한 번만 열기 때문에
    # 접근 승인 창은 문서별로 반복되지 않는다.
    for module_name in ("FilePathCheckerModuleExample", "FilePathCheckerModule"):
        try:
            if hwp.RegisterModule("FilePathCheckDLL", module_name):
                break
        except Exception:
            continue
    return hwp


def _find_text(hwp, text: str) -> bool:
    hwp.HAction.GetDefault("RepeatFind", hwp.HParameterSet.HFindReplace.HSet)
    p = hwp.HParameterSet.HFindReplace
    p.FindString = text
    p.Direction = hwp.FindDir("Forward")
    p.IgnoreMessage = 1
    p.FindType = 1
    return bool(hwp.HAction.Execute("RepeatFind", p.HSet))


def _replace_all(hwp, find_text: str, replace_text: str = "") -> None:
    hwp.HAction.GetDefault("AllReplace", hwp.HParameterSet.HFindReplace.HSet)
    p = hwp.HParameterSet.HFindReplace
    p.FindString = find_text
    p.ReplaceString = replace_text
    p.Direction = hwp.FindDir("All")
    p.IgnoreMessage = 1
    p.FindType = 1
    p.ReplaceMode = 1
    hwp.HAction.Execute("AllReplace", p.HSet)


def _find_from_document_start(hwp, text: str) -> None:
    """Find exact visible text and leave the found text selected."""
    if not hwp.HAction.Run("MoveDocBegin"):
        raise RuntimeError("문서 처음으로 이동하지 못했습니다.")
    if not _find_text(hwp, text):
        raise RuntimeError(f"문서에서 기준 제목을 찾지 못했습니다: {text}")


def _collapse_found_selection_to_start(hwp) -> None:
    """Collapse RepeatFind's selection to its left/start boundary."""
    if not hwp.HAction.Run("MoveLeft"):
        raise RuntimeError("찾은 제목의 시작 위치로 이동하지 못했습니다.")


def trim_document_by_titles(
    hwp,
    current_title: str,
    next_title: str,
    is_first: bool,
) -> None:
    """Keep current-title through immediately before next-title.

    This deliberately avoids Hancom Section navigation.  RepeatFind locates
    visible titles, ordinary edit actions remove the tail first and the head
    second, and SaveAs later lets Hancom build the HWPX package itself.
    """
    if not current_title.strip():
        raise ValueError("현재 사업 제목이 없습니다.")

    # Delete the next business title and everything after it.  Tail-first is
    # important because deleting the head first would shift later positions.
    if next_title.strip():
        _find_from_document_start(hwp, next_title)
        _collapse_found_selection_to_start(hwp)
        if not hwp.HAction.Run("MoveSelDocEnd"):
            raise RuntimeError("다음 사업 제목부터 문서 끝까지 선택하지 못했습니다.")
        if not hwp.HAction.Run("Delete"):
            raise RuntimeError("다음 사업 이후 내용을 삭제하지 못했습니다.")

    # Confirm the current anchor exists even for the first business.  For all
    # other businesses, delete everything before its title.
    _find_from_document_start(hwp, current_title)
    _collapse_found_selection_to_start(hwp)
    if not is_first:
        if not hwp.HAction.Run("MoveSelDocBegin"):
            raise RuntimeError("현재 사업 제목 앞부분을 선택하지 못했습니다.")
        if not hwp.HAction.Run("Delete"):
            raise RuntimeError("현재 사업 제목 앞부분을 삭제하지 못했습니다.")


def _get_hwp_position(hwp) -> tuple[int, int, int]:
    """Return Hancom's (list, paragraph, character) caret position."""
    position = hwp.GetPos()
    if not isinstance(position, (tuple, list)) or len(position) != 3:
        raise RuntimeError(f"한글에서 현재 문서 위치를 읽지 못했습니다: {position!r}")
    return int(position[0]), int(position[1]), int(position[2])


def _get_hwp_section_number(hwp) -> int:
    """Return the current zero-based section number from Hancom's status data."""
    indicator = hwp.KeyIndicator()
    if not isinstance(indicator, (tuple, list)) or len(indicator) < 2:
        raise RuntimeError(f"한글에서 현재 Section 번호를 읽지 못했습니다: {indicator!r}")
    # 생성형 pywin32 래퍼에서는 COM 메서드의 BOOL 반환값도 tuple 첫 칸에
    # 포함된다: (성공, 전체Section수, 현재Section번호, ...).
    # 구형 동적 래퍼는 반환값을 제외한 8개 출력값만 줄 수 있다.
    if len(indicator) >= 9:
        return int(indicator[2])
    return int(indicator[1])


def select_hwp_section(hwp, section_index: int, section_count: int) -> None:
    """Extend a real Hancom selection to the next section boundary."""
    if not 0 <= section_index < section_count:
        raise ValueError(f"Section 번호가 범위를 벗어났습니다: {section_index}")
    if not hwp.HAction.Run("MoveDocBegin"):
        raise RuntimeError("문서 처음으로 이동하지 못했습니다.")
    for _ in range(section_index):
        if not hwp.HAction.Run("MoveSectionDown"):
            raise RuntimeError(f"Section{section_index} 시작 위치로 이동하지 못했습니다.")
    actual_section = _get_hwp_section_number(hwp)
    if actual_section != section_index:
        raise RuntimeError(
            f"요청한 Section{section_index} 대신 Section{actual_section}으로 이동했습니다."
        )

    if section_index + 1 == section_count:
        if not hwp.HAction.Run("MoveSelDocEnd"):
            raise RuntimeError("마지막 Section 전체를 선택하지 못했습니다.")
        return

    # SelectText는 Section 정보 없이 문단 번호만 받는다. 각 Section의 첫 문단이
    # 모두 0번인 문서에서는 빈 블록이 되므로, 선택을 유지한 채 문단 단위로
    # 전진하고 KeyIndicator의 Section 번호가 바뀌는 순간 멈춘다.
    max_moves = 200_000
    for _ in range(max_moves):
        if not hwp.HAction.Run("MoveSelNextParaBegin"):
            raise RuntimeError(f"Section{section_index} 선택 중 문단 이동이 중단됐습니다.")
        if _get_hwp_section_number(hwp) != section_index:
            return
    raise RuntimeError(f"Section{section_index}의 끝을 {max_moves}회 이동 안에 찾지 못했습니다.")


def trim_document_to_section(hwp, section_index: int, section_count: int) -> None:
    """Delete every section except the requested one using Hancom edit actions."""
    if not 0 <= section_index < section_count:
        raise ValueError(f"Section 번호가 범위를 벗어났습니다: {section_index}")

    # 먼저 대상 뒤를 지운다. 다음 Section 시작에서 문서 끝까지 선택한다.
    if section_index + 1 < section_count:
        if not hwp.HAction.Run("MoveDocBegin"):
            raise RuntimeError("문서 처음으로 이동하지 못했습니다.")
        for _ in range(section_index + 1):
            if not hwp.HAction.Run("MoveSectionDown"):
                raise RuntimeError("대상 Section 뒤쪽 경계로 이동하지 못했습니다.")
        if not hwp.HAction.Run("MoveSelDocEnd"):
            raise RuntimeError("대상 Section 뒤쪽을 선택하지 못했습니다.")
        if not hwp.HAction.Run("Delete"):
            raise RuntimeError("대상 Section 뒤쪽을 삭제하지 못했습니다.")

    # 그다음 대상 앞을 지운다. 대상 시작에서 문서 처음까지 역방향 선택한다.
    if section_index > 0:
        if not hwp.HAction.Run("MoveDocBegin"):
            raise RuntimeError("문서 처음으로 이동하지 못했습니다.")
        for _ in range(section_index):
            if not hwp.HAction.Run("MoveSectionDown"):
                raise RuntimeError("대상 Section 시작으로 이동하지 못했습니다.")
        if not hwp.HAction.Run("MoveSelDocBegin"):
            raise RuntimeError("대상 Section 앞쪽을 선택하지 못했습니다.")
        if not hwp.HAction.Run("Delete"):
            raise RuntimeError("대상 Section 앞쪽을 삭제하지 못했습니다.")


def save_selected_block_as_hwp(hwp, output: Path) -> Path:
    """Save the current selection as an intermediate HWP through Hancom."""
    output.parent.mkdir(parents=True, exist_ok=True)
    _backup_existing(output)
    hwp.HAction.GetDefault("SaveBlockAction", hwp.HParameterSet.HFileSaveBlock.HSet)
    parameter_set = hwp.HParameterSet.HFileSaveBlock.HSet
    # 일부 한글 버전의 생성형 COM 객체는 FileName/Format/Argument를
    # Python 속성으로 노출하지 않는다. HSet의 공식 항목 이름으로 넣어야 한다.
    parameter_set.SetItem("FileName", str(output.resolve()))
    parameter_set.SetItem("Format", "HWP")
    parameter_set.SetItem("Argument", "lock:false")
    if not hwp.HAction.Execute("SaveBlockAction", parameter_set):
        raise RuntimeError("한글의 HWP 블록 저장 기능이 실패했습니다.")
    if detect_document_type(output) != "HWP5":
        raise RuntimeError("한글이 실제 HWP 중간파일을 만들지 못했습니다.")
    return output


def convert_open_hwp_to_hwpx(hwp, source_hwp: Path, output: Path) -> Path:
    """Open one intermediate HWP and let Hancom save a complete HWPX."""
    output.parent.mkdir(parents=True, exist_ok=True)
    _backup_existing(output)
    opened = bool(hwp.Open(str(source_hwp.resolve()), "", "forceopen:true;suspendpassword:true"))
    if not opened:
        raise RuntimeError("분할된 HWP 중간파일을 다시 열지 못했습니다.")
    try:
        if not hwp.SaveAs(str(output.resolve()), "HWPX", "lock:false"):
            raise RuntimeError("한글의 HWPX 변환 저장 기능이 실패했습니다.")
    finally:
        try:
            hwp.Clear(1)
        except Exception:
            pass
    if detect_document_type(output) != "HWPX":
        raise RuntimeError("한글이 실제 HWPX 결과파일을 만들지 못했습니다.")
    return output


def convert_integrated_to_hwpx(source: Path, destination: Path, visible: bool = False) -> Path:
    """Open the integrated document once and create a real multi-section HWPX."""
    if detect_document_type(source) == "HWPX":
        return source
    destination.parent.mkdir(parents=True, exist_ok=True)
    hwp = _dispatch_hwp(visible)
    opened = False
    try:
        opened = bool(hwp.Open(str(source.resolve()), "", "forceopen:true;suspendpassword:true"))
        if not opened:
            raise RuntimeError("통합 HWP 파일을 열지 못했습니다.")
        saved = bool(hwp.SaveAs(str(destination.resolve()), "HWPX", "lock:false"))
        if not saved:
            raise RuntimeError("통합문서를 HWPX로 변환하지 못했습니다.")
    finally:
        try:
            if opened:
                try:
                    hwp.Clear(1)
                except Exception:
                    pass
        finally:
            try:
                hwp.Quit()
            except Exception:
                pass
    if detect_document_type(destination) != "HWPX":
        raise RuntimeError("변환 결과가 실제 HWPX 형식이 아닙니다.")
    return destination


def hwpx_section_paths(path: Path) -> list[tuple[int, str]]:
    with zipfile.ZipFile(path) as archive:
        found = []
        for name in archive.namelist():
            match = HWPX_SECTION_RE.match(name)
            if match:
                found.append((int(match.group(1)), name))
    return sorted(found)


def _xml_attr(tag: str, name: str) -> str:
    match = re.search(rf"\b{re.escape(name)}\s*=\s*(['\"])(.*?)\1", tag, flags=re.IGNORECASE | re.DOTALL)
    return match.group(2) if match else ""


def _set_xml_attr(tag: str, name: str, value: str) -> str:
    pattern = re.compile(rf"(\b{re.escape(name)}\s*=\s*)(['\"])(.*?)\2", flags=re.IGNORECASE | re.DOTALL)
    if not pattern.search(tag):
        raise ValueError(f"XML 태그에 {name} 속성이 없습니다.")
    return pattern.sub(lambda m: f"{m.group(1)}{m.group(2)}{value}{m.group(2)}", tag, count=1)


def _rewrite_content_hpf(data: bytes, selected_path: str) -> bytes:
    """Patch only section item/ref tags so Hancom's original XML serialization stays intact."""
    text = data.decode("utf-8")
    item_pattern = re.compile(r"<(?:[A-Za-z_][\w.-]*:)?item\b[^>]*\bhref\s*=\s*(['\"])[^'\"]+\1[^>]*/>", re.IGNORECASE)
    section_items = [tag for tag in item_pattern.findall(text)]
    # findall above contains quote groups only; use finditer for full tags.
    section_tags = []
    for match in item_pattern.finditer(text):
        tag = match.group(0)
        path = _section_path_from_value(_xml_attr(tag, "href"))
        if path:
            section_tags.append((tag, path, _xml_attr(tag, "id")))
    selected = next((x for x in section_tags if x[1].casefold() == selected_path.casefold()), None)
    if selected is None:
        raise ValueError("선택한 Section이 HWPX manifest에 없습니다.")
    selected_tag, _, selected_id = selected
    new_item = _set_xml_attr(_set_xml_attr(selected_tag, "id", "section0"), "href", "Contents/section0.xml")
    emitted_item = False

    def replace_item(match: re.Match[str]) -> str:
        nonlocal emitted_item
        tag = match.group(0)
        if _section_path_from_value(_xml_attr(tag, "href")) is None:
            return tag
        if not emitted_item:
            emitted_item = True
            return new_item
        return ""

    text = item_pattern.sub(replace_item, text)
    old_ids = {item_id for _, _, item_id in section_tags}
    ref_pattern = re.compile(r"<(?:[A-Za-z_][\w.-]*:)?itemref\b[^>]*\bidref\s*=\s*(['\"])[^'\"]+\1[^>]*/>", re.IGNORECASE)
    section_refs = [m.group(0) for m in ref_pattern.finditer(text) if _xml_attr(m.group(0), "idref") in old_ids]
    selected_ref = next((tag for tag in section_refs if _xml_attr(tag, "idref") == selected_id), None)
    if selected_ref is None:
        selected_ref = '<opf:itemref idref="section0"/>'
    else:
        selected_ref = _set_xml_attr(selected_ref, "idref", "section0")
    emitted_ref = False

    def replace_ref(match: re.Match[str]) -> str:
        nonlocal emitted_ref
        tag = match.group(0)
        if _xml_attr(tag, "idref") not in old_ids:
            return tag
        if not emitted_ref:
            emitted_ref = True
            return selected_ref
        return ""

    text = ref_pattern.sub(replace_ref, text)
    if not emitted_ref:
        text, count = re.subn(r"</(?:[A-Za-z_][\w.-]*:)?spine>", selected_ref + "</opf:spine>", text, count=1, flags=re.IGNORECASE)
        if count != 1:
            raise ValueError("HWPX content.hpf에서 spine을 찾지 못했습니다.")
    # 한글이 생성한 HPF는 여러 표준 네임스페이스 선언을 루트에 둔다.
    # 일부 한글 버전은 사용되지 않는 선언이 제거된 HPF도 손상으로 판정한다.
    text = re.sub(
        r"^\s*<\?xml[^?]*\?>",
        '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>',
        text,
        count=1,
        flags=re.IGNORECASE,
    )
    root_match = re.search(r"<opf:package\b[^>]*>", text, flags=re.IGNORECASE | re.DOTALL)
    if root_match is None:
        raise ValueError("HWPX content.hpf에서 opf:package를 찾지 못했습니다.")
    root_tag = root_match.group(0)
    for prefix, uri in HPF_NAMESPACES:
        if not re.search(rf"\bxmlns:{re.escape(prefix)}\s*=", root_tag, flags=re.IGNORECASE):
            root_tag = root_tag[:-1] + f' xmlns:{prefix}="{uri}">'
    text = text[:root_match.start()] + root_tag + text[root_match.end():]
    return text.encode("utf-8")


def _section_path_from_value(value: str) -> str | None:
    normalized = value.replace("\\", "/").lstrip("./")
    return normalized if HWPX_SECTION_RE.match(normalized) else None


def _rewrite_container_rdf(data: bytes, selected_path: str) -> bytes:
    """Patch RDF Description blocks without reserializing Hancom's XML."""
    text = data.decode("utf-8")
    description_pattern = re.compile(
        r"<rdf:Description\b[^>]*>.*?</rdf:Description>",
        flags=re.IGNORECASE | re.DOTALL,
    )
    found_section = False
    found_selected = False

    def replace_description(match: re.Match[str]) -> str:
        nonlocal found_section, found_selected
        block = match.group(0)
        values = re.findall(r"\b(?:rdf:about|rdf:resource)\s*=\s*(['\"])(.*?)\1", block, flags=re.IGNORECASE)
        paths = [(raw, _section_path_from_value(raw)) for _, raw in values]
        section_paths = [(raw, path) for raw, path in paths if path]
        if not section_paths:
            return block
        found_section = True
        distinct = {path.casefold() for _, path in section_paths}
        if len(distinct) != 1:
            raise ValueError("container.rdf의 한 Description이 여러 Section을 동시에 참조합니다.")
        raw_value, path = section_paths[0]
        if path.casefold() != selected_path.casefold():
            return ""
        found_selected = True
        return block.replace(raw_value, "Contents/section0.xml")

    text = description_pattern.sub(replace_description, text)
    if found_section and not found_selected:
        raise ValueError("선택한 Section이 META-INF/container.rdf에 없습니다.")
    return text.encode("utf-8")


def _backup_existing(path: Path) -> None:
    if not path.exists():
        return
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup = path.with_name(f"{path.stem}.backup_{stamp}{path.suffix}")
    shutil.move(str(path), str(backup))


def split_hwpx_section(source_hwpx: Path, section_index: int, output: Path, project_name: str) -> Path:
    sections = dict(hwpx_section_paths(source_hwpx))
    if section_index not in sections:
        raise ValueError(f"변환된 HWPX에 Section{section_index}이 없습니다.")
    selected_path = sections[section_index]
    output.parent.mkdir(parents=True, exist_ok=True)
    _backup_existing(output)
    temp_output = output.with_name(output.name + ".tmp")
    if temp_output.exists():
        temp_output.unlink()

    with zipfile.ZipFile(source_hwpx) as src, zipfile.ZipFile(temp_output, "w") as dst:
        for info in src.infolist():
            name = info.filename
            match = HWPX_SECTION_RE.match(name)
            if match and name != selected_path:
                continue
            if name == selected_path:
                target = deepcopy(info)
                target.filename = "Contents/section0.xml"
                dst.writestr(target, src.read(info))
            elif name == "Contents/content.hpf":
                dst.writestr(info, _rewrite_content_hpf(src.read(info), selected_path))
            elif name == "META-INF/container.rdf":
                dst.writestr(info, _rewrite_container_rdf(src.read(info), selected_path))
            elif name == "Preview/PrvText.txt":
                dst.writestr(info, project_name.encode("utf-8"))
            else:
                dst.writestr(info, src.read(info))
    os.replace(temp_output, output)
    return output


def make_named_copy(source: Path, destination: Path) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    _backup_existing(destination)
    shutil.copy2(source, destination)
    return destination


def _set_heading_page_breaks(xml_text: str) -> tuple[str, int]:
    """Set pageBreak=1 on headings 2-5 and exact `참고 N` headings."""
    changed = 0
    paragraph_pattern = re.compile(
        r"(<(?:[A-Za-z0-9_]+:)?p\b[^>]*)(>.*?</(?:[A-Za-z0-9_]+:)?p>)",
        flags=re.DOTALL,
    )

    def rewrite(match: re.Match[str]) -> str:
        nonlocal changed
        opening, body = match.group(1), match.group(2)
        chunks = re.findall(
            r"<(?:[A-Za-z0-9_]+:)?t\b[^>]*>(.*?)</(?:[A-Za-z0-9_]+:)?t>",
            body,
            flags=re.DOTALL,
        )
        visible = html.unescape(re.sub(r"<[^>]+>", "", "".join(chunks)))
        normalized = normalize_name(visible)
        is_main_heading = any(
            normalized.startswith(normalize_name(title)) for title in PAGE_BREAK_HEADINGS
        )
        is_appendix_heading = bool(re.fullmatch(r"참고\d+", normalized))
        if not (is_main_heading or is_appendix_heading):
            return match.group(0)
        if re.search(r'\bpageBreak="[01]"', opening):
            new_opening = re.sub(r'\bpageBreak="[01]"', 'pageBreak="1"', opening, count=1)
        else:
            new_opening = opening + ' pageBreak="1"'
        if new_opening != opening:
            changed += 1
        return new_opening + body

    return paragraph_pattern.sub(rewrite, xml_text), changed


def _table_span_containing(xml_text: str, position: int) -> tuple[int, int] | None:
    """Return the innermost hp:tbl span containing a character position."""
    token_pattern = re.compile(r"<hp:tbl\b[^>]*>|</hp:tbl>")
    stack: list[int] = []
    for match in token_pattern.finditer(xml_text, 0, position):
        if match.group(0).startswith("</"):
            if stack:
                stack.pop()
        else:
            stack.append(match.start())
    if not stack:
        return None
    start = stack[-1]
    depth = 1
    for match in token_pattern.finditer(xml_text, position):
        if match.group(0).startswith("</"):
            depth -= 1
            if depth == 0:
                return start, match.end()
        else:
            depth += 1
    return None


def _remove_tables_containing_text(xml_text: str, target_text: str) -> tuple[str, int]:
    """Remove complete table objects containing the exact banner text."""
    removed = 0
    while target_text in xml_text:
        position = xml_text.find(target_text)
        span = _table_span_containing(xml_text, position)
        if span is None:
            xml_text = xml_text[:position] + xml_text[position + len(target_text):]
        else:
            start, end = span
            xml_text = xml_text[:start] + xml_text[end:]
            removed += 1
    return xml_text, removed


def postprocess_output_hwpx(path: Path) -> tuple[int, int]:
    """Remove the banner table and add page breaks before headings and appendices."""
    if detect_document_type(path) != "HWPX":
        raise ValueError("후처리할 파일이 실제 HWPX 형식이 아닙니다.")
    temp_output = path.with_name(f".{path.name}.postprocess.tmp")
    banner_count = 0
    page_break_count = 0
    try:
        with zipfile.ZipFile(path) as src, zipfile.ZipFile(temp_output, "w") as dst:
            for info in src.infolist():
                data = src.read(info)
                if info.filename.startswith("Contents/section") and info.filename.endswith(".xml"):
                    xml_text = data.decode("utf-8")
                    xml_text, removed = _remove_tables_containing_text(xml_text, BANNER_TEXT)
                    banner_count += removed
                    xml_text, changed = _set_heading_page_breaks(xml_text)
                    page_break_count += changed
                    data = xml_text.encode("utf-8")
                elif info.filename == "Preview/PrvText.txt":
                    data = data.decode("utf-8", errors="ignore").replace(BANNER_TEXT, "").encode("utf-8")
                dst.writestr(info, data)
        os.replace(temp_output, path)
    finally:
        if temp_output.exists():
            temp_output.unlink()
    return banner_count, page_break_count


def extract_hwpx_text(path: Path) -> str:
    if detect_document_type(path) != "HWPX":
        raise ValueError("출력 파일이 실제 HWPX 형식이 아닙니다.")
    chunks: list[str] = []
    with zipfile.ZipFile(path) as archive:
        names = sorted(n for n in archive.namelist() if n.startswith("Contents/section") and n.endswith(".xml"))
        if not names:
            raise ValueError("출력 HWPX에 본문 Section이 없습니다.")
        for name in names:
            data = archive.read(name).decode("utf-8", errors="ignore")
            chunks.extend(re.findall(r"<[^:>]+:t[^>]*>(.*?)</[^:>]+:t>", data, flags=re.DOTALL))
    return " ".join(re.sub(r"<[^>]+>", "", chunk) for chunk in chunks)


def validate_output(
    path: Path,
    project_name: str,
    source_title: str = "",
    next_title: str = "",
    appendix_markers: str = "",
) -> None:
    if not path.is_file() or path.stat().st_size < 1000:
        raise ValueError("출력 파일이 없거나 크기가 비정상입니다.")
    sections = hwpx_section_paths(path)
    with zipfile.ZipFile(path) as archive:
        nonempty_sections = [
            (index, section_path)
            for index, section_path in sections
            if normalize_name(" ".join(_hwpx_paragraph_texts(archive.read(section_path))))
        ]
    if len(nonempty_sections) != 1:
        raise ValueError(
            "출력 HWPX에서 내용이 있는 본문 Section이 "
            f"1개가 아닙니다: 전체 {len(sections)}개 / 내용 있음 {len(nonempty_sections)}개"
        )
    existing_section_paths = {name.casefold() for _, name in sections}
    with zipfile.ZipFile(path) as archive:
        for metadata_name in ("Contents/content.hpf", "META-INF/container.rdf"):
            if metadata_name not in archive.namelist():
                continue
            metadata = archive.read(metadata_name).decode("utf-8", errors="ignore")
            referenced = {
                "Contents/" + match.group(1)
                for match in re.finditer(r"(?:Contents/)?(section\d+\.xml)", metadata, flags=re.IGNORECASE)
            }
            missing = sorted(x for x in referenced if x.casefold() not in existing_section_paths)
            if missing:
                raise ValueError(f"{metadata_name}가 없는 Section을 참조합니다: {', '.join(missing)}")
    text = extract_hwpx_text(path)
    normalized = normalize_name(text)
    if not project_name_matches_text(project_name, text):
        raise ValueError("출력 HWPX에서 세부사업명을 확인하지 못했습니다.")
    if source_title and normalize_name(source_title) not in normalized:
        raise ValueError("출력 HWPX에서 현재 사업의 전체 제목을 확인하지 못했습니다.")
    if next_title and normalize_name(next_title) in normalized:
        raise ValueError("출력 HWPX에 다음 사업 제목이 남아 있습니다.")
    if BANNER_TEXT in text:
        raise ValueError(f"출력 HWPX에 제거 대상 문구 '{BANNER_TEXT}'이 남아 있습니다.")
    marker_count = end_marker_count(text)
    if marker_count != 1:
        raise ValueError(
            f"출력 HWPX의 '{END_MARKER_TEXT}' 문구가 {marker_count}개입니다. "
            "사업 하나만 분리됐는지 확인하세요."
        )
    missing_appendices = [
        marker
        for marker in appendix_markers.split("|")
        if marker and normalize_name(marker) not in normalized
    ]
    if missing_appendices:
        raise ValueError("출력 HWPX에서 추가자료 표식을 찾지 못했습니다: " + ", ".join(missing_appendices))
    if any(normalize_name(x) in normalized for x in PLACEHOLDER_TEXTS):
        raise ValueError("출력 HWPX에 비공개 안내문이 남아 있습니다.")


def write_log(path: Path, items: Iterable[WorkItem]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(WorkItem.__dataclass_fields__)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(item) for item in items)


def update_excel_copy(source_excel: Path, output_excel: Path, items: list[WorkItem], worker: str) -> None:
    if os.name != "nt":
        raise RuntimeError("엑셀 결과 반영은 Microsoft Excel이 설치된 Windows에서 실행됩니다.")
    try:
        import win32com.client
    except ImportError as exc:
        raise RuntimeError("pywin32가 설치되지 않았습니다.") from exc
    output_excel.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source_excel, output_excel)
    excel = win32com.client.DispatchEx("Excel.Application")
    excel.Visible = False
    excel.DisplayAlerts = False
    workbook = None
    try:
        workbook = excel.Workbooks.Open(str(output_excel.resolve()))
        sheet = workbook.Worksheets("확인자료")
        used_cols = int(sheet.UsedRange.Columns.Count)
        headers = {str(sheet.Cells(1, col).Value).strip(): col for col in range(1, used_cols + 1)}
        required = ["작업일", "작업자", "상태", "비고", "완료여부"]
        missing = [x for x in required if x not in headers]
        if missing:
            raise RuntimeError("엑셀 결과 열이 없습니다: " + ", ".join(missing))
        today = datetime.now().strftime("%y.%m.%d")
        for item in items:
            if item.row_number <= 1 or item.status not in {"완료", "실패"}:
                continue
            success = item.status == "완료"
            sheet.Cells(item.row_number, headers["작업일"]).NumberFormat = "@"
            sheet.Cells(item.row_number, headers["작업일"]).Value = today
            sheet.Cells(item.row_number, headers["작업자"]).Value = worker
            sheet.Cells(item.row_number, headers["상태"]).Value = "" if success else "상태이상"
            sheet.Cells(item.row_number, headers["비고"]).Value = item.reason
            sheet.Cells(item.row_number, headers["완료여부"]).Value = "O" if success else "X"
        workbook.Save()
    finally:
        if workbook is not None:
            workbook.Close(SaveChanges=True)
        excel.Quit()


def execute_plan(
    source: Path,
    excel: Path,
    output_folder: Path,
    items: list[WorkItem],
    worker: str,
    visible: bool = False,
    limit: int | None = None,
) -> tuple[int, int, str]:
    completed = 0
    failed = 0
    processable = [item for item in items if item.status == "처리가능"]
    if limit is not None:
        processable = processable[:limit]
    if processable:
        output_folder.mkdir(parents=True, exist_ok=True)
        hwp = _dispatch_hwp(visible)
        for item in processable:
            opened = False
            stage = "한글 통합문서 열기"
            try:
                opened = bool(hwp.Open(str(source.resolve()), "", "forceopen:true;suspendpassword:true"))
                if not opened:
                    raise RuntimeError("통합 한글 문서를 열지 못했습니다.")
                if item.section_index is None or not item.source_title:
                    raise ValueError("사업 번호 또는 문서 제목이 없습니다.")
                stage = "사업 제목을 기준으로 앞뒤 내용 삭제"
                trim_document_by_titles(
                    hwp,
                    current_title=item.source_title,
                    next_title=item.next_title,
                    is_first=item.section_index == 0,
                )
                stage = "남은 사업을 HWPX로 일반 저장"
                output = Path(item.output_path)
                output.parent.mkdir(parents=True, exist_ok=True)
                _backup_existing(output)
                if not hwp.SaveAs(str(output.resolve()), "HWPX", "lock:false"):
                    raise RuntimeError("한글의 HWPX 일반 저장 기능이 실패했습니다.")
                # 저장 파일을 한글에서 닫은 뒤 ZIP/XML 후처리를 수행한다.
                hwp.Clear(1)
                opened = False
                stage = "반복 표제 제거 및 2~5번 쪽 나누기 적용"
                postprocess_output_hwpx(output)
                stage = "코드명 HWPX 내용 검증"
                validate_output(
                    output,
                    item.excel_project_name,
                    source_title=item.source_title,
                    next_title=item.next_title,
                    appendix_markers=item.appendix_markers,
                )
                stage = "사업명 HWPX 복사"
                make_named_copy(output, Path(item.named_output_path))
                stage = "사업명 HWPX 내용 검증"
                validate_output(
                    Path(item.named_output_path),
                    item.excel_project_name,
                    source_title=item.source_title,
                    next_title=item.next_title,
                    appendix_markers=item.appendix_markers,
                )
                item.status = "완료"
                item.reason = (
                    "사업 제목으로 앞뒤 삭제 후 '5. 기타 추가자료' 1개 및 "
                    "코드명/사업명 HWPX 검증 완료"
                )
                completed += 1
            except Exception as exc:
                item.status = "실패"
                item.reason = f"{stage} 실패: {type(exc).__name__}: {exc}"
                failed += 1
            finally:
                if opened:
                    try:
                        hwp.Clear(1)
                    except Exception:
                        pass

        try:
            hwp.Quit()
        except Exception:
            pass
    write_log(output_folder / "작업결과.csv", items)
    result_excel = output_folder / f"작업결과_{excel.name}"
    excel_message = ""
    try:
        update_excel_copy(excel, result_excel, items, worker)
        excel_message = str(result_excel)
    except Exception as exc:
        excel_message = f"엑셀 자동 반영 실패: {exc} (CSV 로그는 저장됨)"
    return completed, failed, excel_message


def launch_gui() -> None:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    class App(tk.Tk):
        def __init__(self) -> None:
            super().__init__()
            self.title(APP_NAME)
            self.geometry("1250x760")
            self.minsize(950, 600)
            self.template_var = tk.StringVar()
            self.integrated_var = tk.StringVar()
            self.excel_var = tk.StringVar()
            self.output_var = tk.StringVar()
            self.worker_var = tk.StringVar()
            self.visible_var = tk.BooleanVar(value=False)
            self.summary_var = tk.StringVar(value="자료를 선택한 뒤 사전 검사를 실행하세요.")
            self.items: list[WorkItem] = []
            self._build()

        def _build(self) -> None:
            outer = ttk.Frame(self, padding=14)
            outer.pack(fill="both", expand=True)
            fields = [
                ("첨부폴더 1", self.template_var, self.choose_template),
                ("첨부파일 2 통합문서", self.integrated_var, self.choose_integrated),
                ("첨부폴더 3 기준 엑셀", self.excel_var, self.choose_excel),
                ("완료 파일 저장 폴더", self.output_var, self.choose_output),
            ]
            for row, (label, var, cmd) in enumerate(fields):
                ttk.Label(outer, text=label, width=24).grid(row=row, column=0, sticky="w", pady=4)
                ttk.Entry(outer, textvariable=var).grid(row=row, column=1, sticky="ew", padx=6)
                ttk.Button(outer, text="선택", command=cmd).grid(row=row, column=2)
            ttk.Label(outer, text="작업자").grid(row=4, column=0, sticky="w", pady=4)
            ttk.Entry(outer, textvariable=self.worker_var).grid(row=4, column=1, sticky="ew", padx=6)
            ttk.Checkbutton(outer, text="작업 중 한글 창 표시(문제 확인용)", variable=self.visible_var).grid(row=5, column=1, sticky="w", padx=6)
            outer.columnconfigure(1, weight=1)

            actions = ttk.Frame(outer)
            actions.grid(row=6, column=0, columnspan=3, sticky="ew", pady=(12, 8))
            ttk.Button(actions, text="1. 사전 검사", command=self.preview).pack(side="left")
            ttk.Button(actions, text="2. 첫 3건 시험", command=self.execute_three).pack(side="left", padx=8)
            ttk.Button(actions, text="3. 전체 실행", command=self.execute_all).pack(side="left")
            ttk.Button(actions, text="검사표 저장", command=self.save_preview).pack(side="left")

            cols = ("row", "dept", "code", "excel", "section", "source", "status", "reason")
            names = {"row":"행", "dept":"소관", "code":"파일명", "excel":"엑셀 세부사업명", "section":"Section", "source":"문서 사업명", "status":"상태", "reason":"판정 사유"}
            widths = {"row":45,"dept":90,"code":190,"excel":190,"section":60,"source":260,"status":80,"reason":260}
            self.tree = ttk.Treeview(outer, columns=cols, show="headings", height=22)
            for col in cols:
                self.tree.heading(col, text=names[col])
                self.tree.column(col, width=widths[col], anchor="w")
            self.tree.grid(row=7, column=0, columnspan=3, sticky="nsew")
            ybar = ttk.Scrollbar(outer, orient="vertical", command=self.tree.yview)
            ybar.grid(row=7, column=3, sticky="ns")
            self.tree.configure(yscrollcommand=ybar.set)
            outer.rowconfigure(7, weight=1)
            ttk.Label(outer, textvariable=self.summary_var).grid(row=8, column=0, columnspan=3, sticky="w", pady=(8, 0))

        def choose_template(self) -> None:
            value = filedialog.askdirectory()
            if value:
                self.template_var.set(value)

        def choose_integrated(self) -> None:
            value = filedialog.askopenfilename(filetypes=[("한글 문서", "*.hwp *.hwpx")])
            if value:
                self.integrated_var.set(value)

        def choose_excel(self) -> None:
            value = filedialog.askopenfilename(filetypes=[("엑셀", "*.xls *.xlsx")])
            if value:
                self.excel_var.set(value)

        def choose_output(self) -> None:
            value = filedialog.askdirectory()
            if value:
                self.output_var.set(value)

        def paths(self) -> tuple[Path, Path, Path, Path]:
            templates = Path(self.template_var.get())
            integrated = Path(self.integrated_var.get())
            excel = Path(self.excel_var.get())
            output = Path(self.output_var.get())
            if not templates.is_dir():
                raise ValueError("첨부폴더 1을 선택하세요.")
            if not integrated.is_file():
                raise ValueError("첨부파일 2의 통합문서를 선택하세요.")
            if not excel.is_file():
                raise ValueError("첨부폴더 3의 기준 엑셀을 선택하세요.")
            if not self.output_var.get().strip():
                raise ValueError("완료 파일 저장 폴더를 지정하세요.")
            if output.resolve() == templates.resolve():
                raise ValueError("안전을 위해 완료 폴더는 원본 폴더와 다르게 지정하세요.")
            return templates, integrated, excel, output

        def preview(self) -> None:
            try:
                templates, integrated, excel, output = self.paths()
                self.items, warnings = build_work_plan(templates, integrated, excel, output)
                self.display()
                if warnings:
                    messagebox.showwarning("사전 검사 참고", "\n".join(warnings))
            except Exception as exc:
                messagebox.showerror("사전 검사 실패", str(exc))

        def display(self) -> None:
            self.tree.delete(*self.tree.get_children())
            counts: dict[str, int] = {}
            for item in self.items:
                counts[item.status] = counts.get(item.status, 0) + 1
                self.tree.insert("", "end", values=(item.row_number, item.department, item.file_code,
                    item.excel_project_name, "" if item.section_index is None else item.section_index,
                    item.source_title, item.status, item.reason))
            self.summary_var.set(" / ".join(f"{k} {v}건" for k, v in counts.items()))

        def save_preview(self) -> None:
            if not self.items:
                messagebox.showwarning("확인", "먼저 사전 검사를 실행하세요.")
                return
            value = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")])
            if value:
                write_log(Path(value), self.items)
                messagebox.showinfo("저장 완료", value)

        def execute_three(self) -> None:
            self.execute(limit=3)

        def execute_all(self) -> None:
            self.execute(limit=None)

        def execute(self, limit: int | None = None) -> None:
            if not self.items:
                messagebox.showwarning("확인", "먼저 사전 검사를 실행하세요.")
                return
            if not self.worker_var.get().strip():
                messagebox.showwarning("확인", "작업자 이름을 입력하세요.")
                return
            count = sum(item.status == "처리가능" for item in self.items)
            if count == 0:
                messagebox.showinfo("확인", "자동 처리 가능한 항목이 없습니다.")
                return
            test_count = min(limit or count, count)
            label = f"첫 {test_count}건을 시험 저장" if limit else f"처리 가능 {count}건을 전체 저장"
            if not messagebox.askyesno("실행 확인", f"{label}할까요?\n원본 파일은 변경하지 않습니다."):
                return
            try:
                _, integrated, excel, output = self.paths()
                output.mkdir(parents=True, exist_ok=True)
                self.summary_var.set("한글에서 현재·다음 사업 제목을 찾아 앞뒤를 삭제하고 있습니다. 보안 창은 '모두 허용'을 누르세요.")
                self.update_idletasks()
                done, failed, excel_message = execute_plan(
                    integrated, excel, output, self.items, self.worker_var.get().strip(),
                    self.visible_var.get(), limit=limit,
                )
                self.display()
                next_step = (
                    "\n생성된 1개 파일을 한글에서 직접 열어 손상 여부와 첫·마지막 쪽을 확인한 뒤 전체 실행하세요."
                    if limit and done else ""
                )
                messagebox.showinfo(
                    "작업 완료",
                    f"완료 {done}건 / 실패 {failed}건\n"
                    f"코드명 파일: {CODE_OUTPUT_FOLDER} 폴더\n"
                    f"사업명 파일: {NAMED_OUTPUT_FOLDER} 폴더\n"
                    f"{excel_message}{next_step}",
                )
            except Exception as exc:
                messagebox.showerror("실행 실패", str(exc))

    App().mainloop()


def cli() -> int:
    parser = argparse.ArgumentParser(description=APP_NAME)
    parser.add_argument("--templates")
    parser.add_argument("--integrated")
    parser.add_argument("--excel")
    parser.add_argument("--output")
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--worker", default="")
    args = parser.parse_args()
    if not all([args.templates, args.integrated, args.excel, args.output]):
        launch_gui()
        return 0
    items, warnings = build_work_plan(Path(args.templates), Path(args.integrated), Path(args.excel), Path(args.output))
    write_log(Path(args.output) / "사전검사.csv", items)
    for warning in warnings:
        print("주의:", warning)
    if not args.check:
        done, failed, message = execute_plan(Path(args.integrated), Path(args.excel), Path(args.output), items, args.worker)
        print(f"완료 {done}건 / 실패 {failed}건 / {message}")
    else:
        counts: dict[str, int] = {}
        for item in items:
            counts[item.status] = counts.get(item.status, 0) + 1
        print(counts)
    return 0


if __name__ == "__main__":
    raise SystemExit(cli())
