@echo off
setlocal
cd /d "%~dp0"

set "PY_CMD="
where py >nul 2>&1
if not errorlevel 1 set "PY_CMD=py -3"

if not defined PY_CMD (
  where python >nul 2>&1
  if not errorlevel 1 set "PY_CMD=python"
)

if not defined PY_CMD goto no_python

%PY_CMD% --version
%PY_CMD% -m pip install -r requirements.txt
if errorlevel 1 goto install_failed

%PY_CMD% main.py
if errorlevel 1 goto app_failed
exit /b 0

:no_python
echo Python 3.11 or later was not found.
echo Install Python and enable "Add python.exe to PATH".
pause
exit /b 1

:install_failed
echo Package installation failed.
pause
exit /b 1

:app_failed
echo The application stopped with an error.
pause
exit /b 1
