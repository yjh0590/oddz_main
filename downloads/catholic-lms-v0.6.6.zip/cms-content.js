(() => {
  if (window.__oddzCatholicCmsInstalled) return;
  window.__oddzCatholicCmsInstalled = true;

  const MIN_MAIN_VIDEO_DURATION = 60;

  const CHECK_MS = 300;
  const PLAYER_SETTLE_MS = 800;
  const REQUEST_RETRY_MS = 900;
  const MAX_REQUESTS = 15;

  const contentId =
    location.pathname.match(/\/em\/([^/?#]+)/)?.[1] || null;

  let autoplayEnabledCache = false;
  let playerSeenAt = null;
  let lastRequestAt = 0;
  let requestCount = 0;
  let requestPending = false;
  let playCommandAccepted = false;

  let watchedVideo = null;
  let finishSent = false;
  let firstObservedTime = 0;
  let maxObservedTime = 0;
  let realProgressObserved = false;

  async function refreshAutoPlayState() {
    try {
      const state = await chrome.storage.local.get(["catholicAutoPlay"]);
      autoplayEnabledCache = Boolean(state.catholicAutoPlay);
    } catch {
      autoplayEnabledCache = false;
    }
  }

  function hasPlayerSurface() {
    return Boolean(
      document.querySelector(".vc-front-screen-play-btn") ||
      [...document.querySelectorAll("video")].some(v => {
        const src = v.currentSrc || v.src || "";
        return src.includes("preloader.mp4");
      })
    );
  }

  function getMainVideo() {
    return [...document.querySelectorAll("video")]
      .filter(v => {
        const src = v.currentSrc || v.src || "";

        return (
          !src.includes("preloader.mp4") &&
          Number.isFinite(v.duration) &&
          v.duration >= MIN_MAIN_VIDEO_DURATION &&
          v.readyState >= 1 &&
          Boolean(src)
        );
      })
      .sort((a, b) => b.duration - a.duration)[0] || null;
  }

  async function requestTrustedPlay() {
    if (requestPending || playCommandAccepted) return;

    const now = Date.now();

    if (now - lastRequestAt < REQUEST_RETRY_MS) return;
    if (requestCount >= MAX_REQUESTS) return;

    requestPending = true;
    lastRequestAt = now;
    requestCount += 1;

    console.log("[오늘의 강의] 브라우저 레벨 UniPlayer 재생 요청", {
      contentId,
      attempt: requestCount
    });

    try {
      const response = await chrome.runtime.sendMessage({
        type: "ODDZ_CDP_PLAY",
        contentId
      });

      if (response?.ok) {
        playCommandAccepted = true;

        console.log("[오늘의 강의] userGesture 재생 명령 성공", {
          contentId,
          attempt: requestCount,
          href: response.href || null,
          hasBeenActive: response.hasBeenActive,
          isActive: response.isActive
        });
      } else {
        console.log("[오늘의 강의] userGesture 재생 대기/실패", {
          contentId,
          attempt: requestCount,
          error: response?.error || "알 수 없는 오류"
        });
      }
    } catch (error) {
      console.log("[오늘의 강의] userGesture 재생 요청 오류", {
        contentId,
        attempt: requestCount,
        error: String(error?.message || error)
      });
    } finally {
      requestPending = false;
    }
  }

  async function handleAutoplay() {
    if (!autoplayEnabledCache || playCommandAccepted) return;

    if (!hasPlayerSurface()) {
      playerSeenAt = null;
      return;
    }

    const now = Date.now();

    if (playerSeenAt === null) {
      playerSeenAt = now;
      return;
    }

    if (now - playerSeenAt < PLAYER_SETTLE_MS) return;

    // 일반 .click(), dispatchEvent(), video.play()가 아니라
    // background에서 CDP Runtime.evaluate(userGesture=true)를 사용한다.
    await requestTrustedPlay();
  }

  function attachFinishWatcher() {
    const video = getMainVideo();
    if (!video || video === watchedVideo) return;

    watchedVideo = video;
    finishSent = false;
    firstObservedTime =
      Number.isFinite(video.currentTime) ? video.currentTime : 0;
    maxObservedTime = firstObservedTime;
    realProgressObserved = false;

    console.log("[오늘의 강의] 본편 종료 감시 연결", {
      contentId,
      duration: video.duration,
      currentTime: video.currentTime
    });

    video.addEventListener("timeupdate", () => {
      if (!Number.isFinite(video.currentTime)) return;

      maxObservedTime = Math.max(maxObservedTime, video.currentTime);

      if (maxObservedTime - firstObservedTime >= 5) {
        realProgressObserved = true;
      }
    });

    video.addEventListener("ended", () => {
      if (finishSent) return;

      const nearRealEnd =
        Number.isFinite(video.duration) &&
        video.duration >= MIN_MAIN_VIDEO_DURATION &&
        video.currentTime >= Math.max(0, video.duration - 1.5);

      if (!realProgressObserved || !nearRealEnd) return;

      finishSent = true;

      console.log("[오늘의 강의] 본편 종료 → 다음 강의 요청", {
        contentId
      });

      setTimeout(() => {
        document.dispatchEvent(
          new CustomEvent("ODDZ_SUPPRESS_BEFOREUNLOAD")
        );

        chrome.runtime.sendMessage({
          type: "LECTURE_FINISHED",
          title: document.title,
          currentTime: video.currentTime,
          duration: video.duration,
          contentId
        }).catch(() => {});
      }, 3000);
    });
  }

  refreshAutoPlayState();
  setInterval(refreshAutoPlayState, 1000);

  setInterval(() => {
    handleAutoplay().catch(console.error);
    attachFinishWatcher();
  }, CHECK_MS);
})();
