export function findDuplicateBookmarks(roots) {
  const groups = new Map();
  const walk = (nodes, parents, managed = false) => {
    for (const node of nodes) {
      const readOnly = managed || Boolean(node.unmodifiable);
      if (node.children) {
        walk(node.children, node.title ? [...parents, node.title] : parents, readOnly);
      } else if (node.url && URL.canParse(node.url)) {
        const url = new URL(node.url);
        if (url.protocol !== 'https:' && url.protocol !== 'http:') continue;
        if (!groups.has(url.href)) groups.set(url.href, []);
        groups.get(url.href).push({
          id: node.id, parentId: node.parentId, title: node.title || url.href,
          folder: parents.join(' › '), readOnly,
        });
      }
    }
  };
  walk(roots, []);
  return [...groups].filter(([, entries]) => entries.length > 1)
    .sort((a, b) => b[1].length - a[1].length || a[0].localeCompare(b[0]));
}

export function sameBookmark(node, entry, url) {
  return node?.id === entry.id && node.parentId === entry.parentId &&
    URL.canParse(node.url) && new URL(node.url).href === url;
}
