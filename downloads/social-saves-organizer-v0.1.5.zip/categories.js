export const otherCategory = '기타';

const categories = [
  ['여행·장소', /여행|관광|호텔|숙소|캠핑|항공권|가볼\s*만한|\b(?:travel|trip|vacation|hotel|sightseeing|camping)\b/gi],
  ['음식·요리', /요리|레시피|맛집|카페|커피|베이킹|디저트|먹방|\bcafé|\b(?:recipe|cooking|baking|restaurant|cafe|coffee|food|dessert)\b/gi],
  ['운동·건강', /운동|헬스|홈트|러닝|요가|필라테스|스트레칭|건강|\b(?:workout|fitness|running|yoga|pilates|stretching|health)\b/gi],
  ['음악', /음악|노래|뮤직비디오|콘서트|연주|가사|\b(?:music|song|concert|guitar|piano|album|official audio)\b/gi],
  ['게임', /게임|공략|마인크래프트|발로란트|롤토체스|\b(?:gaming|gameplay|minecraft|valorant|playthrough)\b/gi],
  ['공부·정보', /공부|강의|튜토리얼|학습|자격증|코딩|프로그래밍|사용법|\b(?:tutorial|course|study|learn|coding|programming|how to)\b/gi],
  ['영화·예능', /영화|드라마|예능|애니메이션|코미디|예고편|\b(?:movie|film|cinema|trailer|comedy|anime)\b/gi],
  ['일상·라이프', /브이로그|일상|패션|인테리어|뷰티|메이크업|스킨케어|\b(?:vlog|lifestyle|fashion|interior|beauty|makeup|skincare)\b/gi],
];

export function itemCategory({ title, description, channel }) {
  const fields = [title, description, channel].map((value) => value?.normalize('NFKC').trim().toLowerCase() || '');
  let best = otherCategory;
  let highScore = 0;
  for (const [category, keywords] of categories) {
    let score = 0;
    for (const [index, text] of fields.entries()) {
      if (text && fields.indexOf(text) === index) {
        const matches = new Set(text.match(keywords) || []);
        score += Math.min(matches.size, 2) * (3 - index);
      }
    }
    if (score > highScore) {
      highScore = score;
      best = category;
    }
  }
  return best;
}
