export const platforms = {
  youtube: {
    name: 'YouTube',
    title: '좋아요한 동영상',
    home: 'https://www.youtube.com/playlist?list=LL',
    openLabel: '좋아요 재생목록 열기',
    pattern: 'https://www.youtube.com/*',
    help: '로그인한 YouTube의 좋아요한 동영상 재생목록을 열고 아래에서 해당 탭을 선택하세요.',
    action: '좋아요 취소',
    done: '좋아요가 취소된 상태를 확인했습니다.',
  },
  'youtube-playlist': {
    name: 'YouTube 재생목록',
    title: '재생목록 동영상',
    home: 'https://www.youtube.com/feed/playlists',
    openLabel: 'YouTube 재생목록 열기',
    pattern: 'https://www.youtube.com/*',
    help: 'YouTube에서 수정할 수 있는 재생목록이나 나중에 볼 동영상을 열고 해당 탭을 선택하세요.',
    action: '재생목록에서 제거',
    done: '재생목록에서 영상이 제거된 상태를 확인했습니다.',
  },
  instagram: {
    name: 'Instagram',
    title: '저장한 게시물',
    home: 'https://www.instagram.com/',
    openLabel: 'Instagram 열기',
    pattern: 'https://www.instagram.com/*',
    help: 'Instagram에서 더 보기 → 저장됨을 열고 해당 탭을 선택하세요. 모든 게시물 목록을 끝까지 불러옵니다.',
    action: '저장 해제',
    done: '저장이 해제된 상태를 확인했습니다.',
  },
};

export function sourceKey(platform, url) {
  if (!url) return null;
  const { origin, pathname, searchParams } = new URL(url);
  if (platform !== 'instagram') {
    if (origin !== 'https://www.youtube.com' || pathname !== '/playlist') return null;
    const listId = searchParams.get('list') || '';
    const allowed = platform === 'youtube' ? listId === 'LL' : /^(?:PL[\w-]+|WL)$/.test(listId);
    return allowed ? origin + '/playlist?list=' + listId : null;
  }
  if (origin === 'https://www.instagram.com' && /^\/[\w.]+\/saved(?:\/[\w-]+)?\/?$/i.test(pathname)) {
    return origin + pathname.replace(/\/$/, '').toLowerCase();
  }
  return null;
}

export const youtubeListDom = {
  list: 'ytd-playlist-video-list-renderer',
  cards: 'ytd-playlist-video-renderer, yt-lockup-view-model, ytd-video-renderer, ytd-rich-item-renderer',
  title: '#video-title, #video-title-link, .ytLockupMetadataViewModelTitle, .yt-lockup-metadata-view-model__title, .yt-lockup-metadata-view-model-wiz__title, yt-lockup-metadata-view-model h3',
  unavailable: '[is-playable="false"], [playable="false"], [is-unavailable]',
  buttons: 'ytd-menu-renderer button, #menu button, button[aria-haspopup="menu"], button[aria-label="Action menu" i], button[aria-label="More actions" i], button[aria-label="더보기"], button[aria-label="작업 메뉴"], .ytLockupMetadataViewModelMenuButton button, .yt-lockup-metadata-view-model__menu-button button, .yt-lockup-metadata-view-model-wiz__menu-button button',
  menu: ':is(ytd-menu-popup-renderer, [role="menu"], yt-sheet-view-model, yt-contextual-sheet-layout) :is([role="menuitem"], ytd-menu-service-item-renderer, tp-yt-paper-item, yt-list-item-view-model)',
};

// Chrome serializes injected functions, so their dependencies live inside them.
export async function readList(platform, expectedSource, scanId, youtubeDom, collections = false) {
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const isYouTube = platform !== 'instagram';
  const currentSource = () => {
    if (isYouTube && location.pathname === '/playlist') {
      return location.origin + '/playlist?list=' + new URLSearchParams(location.search).get('list');
    }
    return (location.origin + location.pathname.replace(/\/$/, '')).toLowerCase();
  };
  const firstText = (...values) => values.map((value) => value?.trim()).find(Boolean) || '';
  const listId = isYouTube ? new URL(expectedSource).searchParams.get('list') : '';
  const rowSelector = `ytd-playlist-video-renderer, ${youtubeDom.list} :is(${youtubeDom.cards}), ` +
    `ytd-browse[page-subtype="playlist"] :is(${youtubeDom.cards}):has(a[href*="list=${CSS.escape(listId)}"])`;
  const rowState = isYouTube
    ? (globalThis.socialSavesPlaylistRows = { source: expectedSource, scanId, tokens: new WeakMap() })
    : null;
  const visible = (element) => element.getClientRects().length &&
    !element.closest('[hidden], [aria-hidden="true"]') && getComputedStyle(element).visibility === 'visible';
  const videoId = (url) => {
    if (url.origin !== location.origin) return null;
    return url.pathname === '/watch'
      ? url.searchParams.get('v')
      : url.pathname.match(/^\/(?:shorts|live)\/([\w-]+)\/?$/)?.[1];
  };
  const collectYouTube = () => {
    const items = new Map();
    for (const card of document.querySelectorAll(rowSelector)) {
      if (!visible(card)) continue;
      const links = [...card.querySelectorAll('a[href]')].filter((link) =>
        link.closest(youtubeDom.cards) === card && (!new URLSearchParams(link.search).has('list') ||
          new URLSearchParams(link.search).get('list') === listId));
      const entry = links.find((link) => videoId(new URL(link.href)));
      const video = entry ? videoId(new URL(entry.href)) : '';
      const titleLink = card.querySelector(youtubeDom.title);
      const titleText = firstText(titleLink?.getAttribute('title'), titleLink?.textContent);
      const placeholderTitle = /^\[?(?:private video|deleted video|video unavailable|unavailable video|비공개 동영상|삭제된 동영상|시청할 수 없는 동영상|사용할 수 없는 동영상)\]?$/i.test(titleText);
      const unavailable = card.matches(youtubeDom.unavailable) || (placeholderTitle &&
        (!video || titleText.startsWith('[') || titleLink?.matches('[aria-disabled="true"]')));
      if ((!video || !/^[\w-]+$/.test(video)) && !unavailable) continue;
      const index = firstText(...links.map((link) => new URLSearchParams(link.search).get('index')),
        card.getAttribute('aria-posinset'), card.querySelector('#index')?.textContent);
      const position = /^\d+$/.test(index) ? Number(index) : null;
      let token = rowState.tokens.get(card);
      if (!token) {
        token = crypto.randomUUID();
        rowState.tokens.set(card, token);
      }
      const id = platform === 'youtube' && video ? video
        : position !== null ? `position-${position}-${video}` : token;
      const image = card?.querySelector(
        '#thumbnail img, ytd-thumbnail img, yt-thumbnail-view-model img, ' +
        'a[class*="content-image" i] img, a[class*="contentimage" i] img, img[src*="/vi/"], img[src*="/vi_webp/"]'
      );
      const channel = card?.querySelector(
        '#channel-name, ytd-channel-name, #byline, ' +
        'yt-content-metadata-view-model a:is([href^="/@"], [href^="/channel/"], [href^="/c/"], [href^="/user/"])'
      );
      const description = card?.querySelector(
        '#description-text, #description-snippet, .metadata-snippet-text, yt-description-snippet-view-model, yt-description-preview-view-model'
      );
      const videoLinks = links.filter((entry) =>
        videoId(new URL(entry.href)) === video && !entry.querySelector('img') &&
        !entry.matches('#thumbnail, [class*="contentimage" i], [class*="content-image" i]'));
      const imageAlt = image?.alt?.trim();
      items.set(id, {
        id,
        token,
        scanId,
        video,
        position,
        unavailable,
        url: video ? location.origin + '/watch?v=' + video : '',
        title: firstText(
          titleText,
          ...videoLinks.flatMap((entry) => [entry.getAttribute('title'), entry.textContent]),
          titleLink?.getAttribute('aria-label'), ...videoLinks.map((entry) => entry.getAttribute('aria-label')),
          /^(thumbnail|video thumbnail|(?:동영상 )?썸네일)$/i.test(imageAlt) ? '' : imageAlt,
          unavailable ? '시청 불가 영상' : ''
        ),
        channel: firstText(channel?.textContent),
        description: firstText(description?.textContent),
        thumbnail: firstText(image?.currentSrc, image?.getAttribute('src'), image?.getAttribute('data-src')),
      });
    }
    const counts = new Map();
    for (const item of items.values()) {
      if (item.video) counts.set(item.video, (counts.get(item.video) || 0) + 1);
    }
    for (const item of items.values()) item.seenTogether = counts.get(item.video) > 1;
    return items;
  };
  const instagramRoot = () => document.querySelector('main, [role="main"]') || document.body;
  const instagramLinks = () => {
    return [...instagramRoot().querySelectorAll('a[href]')].filter((link) =>
      link.origin === location.origin && /^\/(p|reel|tv)\/[\w-]+\/?$/.test(link.pathname));
  };
  const collectionLinks = () => [...instagramRoot().querySelectorAll('a[href]')].filter((link) => {
    const key = (link.origin + link.pathname.replace(/\/$/, '')).toLowerCase();
    return key.startsWith(expectedSource + '/') && /^[\w-]+$/.test(key.slice(expectedSource.length + 1)) &&
      !key.endsWith('/all-posts');
  });
  const collectCollections = () => {
    const found = new Map();
    for (const link of collectionLinks()) {
      const url = link.origin + link.pathname;
      const title = firstText(link.getAttribute('title'), link.textContent, link.getAttribute('aria-label'),
        link.querySelector('img')?.alt, link.pathname.split('/').filter(Boolean).at(-1));
      const id = url.replace(/\/$/, '').toLowerCase();
      found.set(id, { id, title, url });
    }
    return found;
  };
  const listLoading = () => {
    const root = (isYouTube ? document.querySelector(youtubeDom.list) : instagramRoot()) || document.body;
    const loader = '[role="progressbar"], [aria-busy="true"], [aria-label="Loading" i], [aria-label="Loading..." i], [aria-label="로딩 중…"], #spinner[active]';
    return root.matches(loader) || [...root.querySelectorAll(loader)].some(visible);
  };
  const collectInstagram = () => {
    const items = new Map();
    for (const link of instagramLinks()) {
      const [, kind, id] = link.pathname.split('/');
      const image = link.querySelector('img');
      const poster = link.querySelector('video[poster]')?.getAttribute('poster');
      const srcset = image?.getAttribute('srcset') || link.querySelector('picture source[srcset]')?.getAttribute('srcset');
      const candidates = [
        image?.currentSrc, image?.getAttribute('src'), image?.getAttribute('data-src'),
        poster, ...(srcset?.split(',').map((entry) => entry.trim().split(/\s+/)[0]).reverse() || []),
      ];
      const thumbnail = candidates.find((value) => value && /^https:\/\//i.test(value));
      const caption = firstText(link.getAttribute('data-caption'), link.querySelector('figcaption')?.textContent);
      const label = [image?.alt, link.getAttribute('title'), link.getAttribute('aria-label'), link.textContent]
        .map((value) => value?.trim())
        .find((value) => value && !/^(?:(?:open|view) )?(?:photo|image|video|reel|post|thumbnail|사진|이미지|동영상|릴스|게시물|게시물 보기|썸네일)$/i.test(value));
      const previous = items.get(id);
      items.set(id, {
        id,
        url: location.origin + '/' + kind + '/' + id + '/',
        title: previous?.title || caption || label,
        description: previous?.description || caption,
        thumbnail: previous?.thumbnail || thumbnail,
      });
    }
    return items;
  };

  const collect = isYouTube ? collectYouTube : collections ? collectCollections : collectInstagram;
  if (currentSource() !== expectedSource) return { changed: true };
  if (isYouTube) {
    const readMenu = () => [...document.querySelectorAll(youtubeDom.menu)].filter(visible);
    const header = document.querySelector('yt-page-header-renderer, ytd-playlist-header-renderer, ytd-playlist-sidebar-primary-info-renderer');
    const buttons = [...(header?.querySelectorAll(youtubeDom.buttons) || [])].filter(visible);
    if (buttons.length === 1 && !readMenu().length) {
      buttons[0].click();
      for (let attempt = 0; attempt < 8 && currentSource() === expectedSource; attempt++) {
        const menu = readMenu();
        if (menu.length) {
          const option = menu.find((item) => /^(show unavailable videos|(?:시청할|사용할|재생할|볼) 수 없는 동영상 표시)$/i
            .test(firstText(item.getAttribute('aria-label'), item.textContent)));
          if (option) {
            (option.querySelector('button, tp-yt-paper-item, [role="button"]') || option).click();
            await wait(450);
          } else {
            header.click();
          }
          break;
        }
        await wait(150);
      }
    }
  }
  let initial = collect();
  const initialWaitStart = performance.now();
  while (!initial.size &&
      performance.now() - initialWaitStart < (listLoading() ? 15000 : 3000)) {
    await wait(350);
    if (currentSource() !== expectedSource) return { changed: true };
    initial = collect();
  }
  if (!initial.size && listLoading()) return { items: [], incomplete: true };

  const items = new Map();
  const merge = (snapshot) => {
    for (const [id, item] of snapshot) {
      const previous = items.get(id);
      items.set(id, {
        ...item,
        title: item.title || previous?.title,
        channel: item.channel || previous?.channel,
        description: item.description || previous?.description,
        thumbnail: item.thumbnail || previous?.thumbnail,
        seenTogether: item.seenTogether || previous?.seenTogether,
      });
    }
  };

  if (initial.size) {
    const anchor = isYouTube
      ? [...document.querySelectorAll(rowSelector)].at(-1)
      : (collections ? collectionLinks() : instagramLinks()).at(-1);
    let scrollRoot = document.scrollingElement;
    for (let parent = anchor?.parentElement; parent && parent !== document.body; parent = parent.parentElement) {
      if (parent.scrollHeight > parent.clientHeight && /^(auto|scroll|overlay)$/.test(getComputedStyle(parent).overflowY)) {
        scrollRoot = parent;
        break;
      }
    }
    const originalTop = scrollRoot.scrollTop;
    const scroll = (top) => scrollRoot.scrollTo({ top, behavior: 'instant' });
    let lastCount = 0;
    let lastPosition = -1;
    let lastHeight = -1;
    let lastMovement = performance.now();
    let incomplete = false;
    const notice = document.createElement('div');
    notice.setAttribute('role', 'status');
    notice.style.cssText = 'all:initial;position:fixed;z-index:2147483647;bottom:1rem;left:50%;transform:translateX(-50%);max-width:calc(100% - 3rem);padding:.65rem 1rem;border-radius:1rem;background:#2c1938;color:white;box-shadow:0 4px 20px #0005;font:600 14px/1.5 system-ui,sans-serif;text-align:center;pointer-events:none;';
    notice.textContent = '목록을 불러오는 중입니다.';
    document.body.append(notice);
    try {
      if (originalTop > 0) {
        scroll(0);
        await wait(350);
      }
      while (currentSource() === expectedSource) {
        merge(collect());
        const position = scrollRoot.scrollTop;
        const height = scrollRoot.scrollHeight;
        const viewport = scrollRoot.clientHeight;
        if (items.size !== lastCount) {
          lastCount = items.size;
          notice.textContent = `목록을 불러오는 중입니다 · ${lastCount}개 찾음`;
          void chrome.runtime.sendMessage({ type: 'list-scan-progress', scanId, count: lastCount }).catch(() => {});
          lastMovement = performance.now();
        }
        if (position !== lastPosition || height !== lastHeight) {
          lastPosition = position;
          lastHeight = height;
          lastMovement = performance.now();
        }
        const atEnd = position + viewport >= height - 2;
        const idle = performance.now() - lastMovement;
        if (!document.hidden && atEnd && idle >= 6000 && !listLoading()) break;
        if (idle >= 15000) {
          incomplete = true;
          break;
        }
        if (!document.hidden) scroll(atEnd ? height : position + Math.max(1, Math.floor(viewport * 0.85)));
        await wait(atEnd ? 500 : 250);
      }
      if (currentSource() !== expectedSource) return { changed: true };
    } finally {
      notice.remove();
      if (currentSource() === expectedSource && scrollRoot.isConnected) scroll(originalTop);
    }
    if (isYouTube) {
      const byVideo = new Map();
      for (const item of items.values()) {
        if (!item.video) continue;
        if (!byVideo.has(item.video)) byVideo.set(item.video, []);
        byVideo.get(item.video).push(item);
      }
      for (const group of byVideo.values()) {
        if (group.length < 2) continue;
        const identified = group.filter((item) => item.position !== null || item.seenTogether);
        const keep = new Set(identified.length ? identified : [group[0]]);
        for (const item of group) if (!keep.has(item)) items.delete(item.id);
      }
    }
    return { items: [...items.values()], incomplete };
  }

  return { items: [] };
}

export async function removePlaylistVideo(expectedSource, item, youtubeDom) {
  const target = new URL(expectedSource);
  const listId = target.searchParams.get('list');
  const onTarget = () => location.origin === 'https://www.youtube.com' &&
    location.origin === target.origin && location.pathname === '/playlist' &&
    new URLSearchParams(location.search).get('list') === listId;
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const visible = (element) => element.getClientRects().length &&
    !element.closest('[hidden], [aria-hidden="true"], [inert]') &&
    getComputedStyle(element).visibility === 'visible';
  const usable = (element) => visible(element) && !element.matches('[aria-disabled="true"], :disabled');
  const tokens = globalThis.socialSavesPlaylistRows;
  if (!onTarget() || tokens?.source !== expectedSource || tokens.scanId !== item.scanId) return 'wrong-page';
  const selector = `ytd-playlist-video-renderer, ${youtubeDom.list} :is(${youtubeDom.cards}), ` +
    `ytd-browse[page-subtype="playlist"] :is(${youtubeDom.cards}):has(a[href*="list=${CSS.escape(listId)}"])`;
  const describeRows = () => [...document.querySelectorAll(selector)].filter(visible).map((row) => {
    const links = [...row.querySelectorAll('a[href]')].filter((link) => link.origin === target.origin &&
      link.closest(youtubeDom.cards) === row && (!new URLSearchParams(link.search).has('list') ||
        new URLSearchParams(link.search).get('list') === listId));
    const video = links.map((link) => link.pathname === '/watch'
      ? new URLSearchParams(link.search).get('v')
      : link.pathname.match(/^\/(?:shorts|live)\/([\w-]+)\/?$/)?.[1]).find(Boolean) || '';
    const index = links.map((link) => new URLSearchParams(link.search).get('index')).find(Boolean) ||
      row.getAttribute('aria-posinset') || row.querySelector('#index')?.textContent?.trim() || '';
    const title = row.querySelector(youtubeDom.title);
    return {
      row, video, position: /^\d+$/.test(index) ? Number(index) : null, token: tokens.tokens.get(row),
      title: title?.getAttribute('title')?.trim() || title?.textContent?.trim() || '',
      unavailable: row.matches(youtubeDom.unavailable),
    };
  });
  const findRows = () => {
    const entries = describeRows().filter((entry) => entry.video === item.video);
    const held = entries.find((entry) => entry.token === item.token && (item.video ||
      (item.position === null || entry.position === item.position) &&
      (entry.title === item.title || (entry.unavailable && item.title === '시청 불가 영상'))));
    if (held) return [held.row];
    if (!item.video || item.position === null) return [];
    return entries.filter((entry) => entry.position === item.position).map((entry) => entry.row);
  };
  let rows = findRows();
  if (!rows.length) {
    window.scrollTo({ top: 0, behavior: 'instant' });
    await wait(350);
    let endChecks = 0;
    for (let attempt = 0; onTarget() && attempt < 80; attempt++) {
      rows = findRows();
      if (rows.length) break;
      const root = document.scrollingElement;
      endChecks = root.scrollTop + root.clientHeight >= root.scrollHeight - 2 ? endChecks + 1 : 0;
      if (endChecks >= 6) break;
      window.scrollBy({ top: root.clientHeight * 0.85, behavior: 'instant' });
      await wait(350);
    }
  }
  if (!onTarget()) return 'wrong-page';
  if (rows.length > 1) return 'duplicate';
  if (!rows.length) return 'missing';

  const [row] = rows;
  const buttons = [...row.querySelectorAll(youtubeDom.buttons)].filter(usable);
  if (buttons.length !== 1) return 'menu-unavailable';

  const readMenu = () => {
    const nodes = [...document.querySelectorAll(youtubeDom.menu)].filter(usable);
    return nodes.filter((node) => !nodes.some((other) => node !== other && node.contains(other)));
  };
  if (readMenu().length) return 'menu-open';

  const normalize = (value) => (value || '').normalize('NFKC').trim()
    .replace(/[“”]/g, '"').replace(/\s+/g, ' ').toLowerCase();
  const playlistTitle = document.querySelector('yt-page-header-renderer h1, ytd-playlist-header-renderer #title')?.textContent ||
    document.title.replace(/\s*[-–]\s*YouTube\s*$/i, '');
  const names = [normalize(playlistTitle)].filter((name) => name && name !== 'youtube');
  if (listId === 'WL') names.push('watch later', '나중에 볼 동영상', '나중에 볼 영상');
  if (listId === 'LL') names.push('liked videos', '좋아요 표시한 동영상', '좋아요한 동영상');
  const removeLabels = new Set(['remove from playlist', 'remove from this playlist', '재생목록에서 삭제', '재생목록에서 제거']);
  for (const name of names) {
    removeLabels.add('remove from ' + name);
    removeLabels.add('remove from "' + name + '"');
    for (const verb of ['삭제', '제거']) {
      removeLabels.add(name + '에서 ' + verb);
      removeLabels.add('"' + name + '"에서 ' + verb);
    }
  }

  const [button] = buttons;
  const isSameRow = () => {
    const matches = findRows();
    return matches.length === 1 && matches[0] === row;
  };
  button.scrollIntoView({ block: 'nearest', behavior: 'instant' });
  if (!onTarget() || !isSameRow()) return 'missing';
  button.click();
  for (let attempt = 0; attempt < 15 && onTarget(); attempt++) {
    const options = readMenu().filter((option) =>
      [option.textContent, option.getAttribute('aria-label')].some((label) => removeLabels.has(normalize(label))));
    if (options.length === 1 && isSameRow()) {
      const [option] = options;
      const before = describeRows().filter((entry) => entry.video === item.video).length;
      (option.querySelector('button, tp-yt-paper-item, [role="button"]') || option).click();
      let absent = false;
      for (let check = 0; check < 18 && onTarget(); check++) {
        const entries = describeRows().filter((entry) => entry.video === item.video);
        const isAbsent = entries.length < before && !entries.some((entry) => entry.row === row);
        if (absent && isAbsent) return 'removed';
        absent = isAbsent;
        await wait(250);
      }
      return onTarget() ? 'unverified' : 'wrong-page';
    }
    if (options.length > 1) break;
    await wait(200);
  }
  if (!onTarget()) return 'wrong-page';
  if (readMenu().length) document.querySelector('ytd-browse[page-subtype="playlist"]')?.click();
  return 'menu-unavailable';
}

export async function inspectPlaylistDestination(expectedSource, youtubeDom) {
  const key = () => location.origin + location.pathname + '?list=' + new URLSearchParams(location.search).get('list');
  if (key() !== expectedSource) return null;
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const visible = (element) => element.getClientRects().length && !element.closest('[hidden], [aria-hidden="true"]');
  const header = document.querySelector('yt-page-header-renderer, ytd-playlist-header-renderer, ytd-playlist-sidebar-primary-info-renderer');
  const label = header?.querySelector('h1, #title')?.textContent?.trim() ||
    document.title.replace(/\s*[-–]\s*YouTube\s*$/i, '').trim();
  let editable = expectedSource.endsWith('=WL') || Boolean(header?.matches('[is-editable]:not([is-editable="false"])') ||
    header?.querySelector('#title-icon, [aria-label*="Edit title" i], [aria-label*="Edit playlist title" i], [aria-label*="Edit description" i], [aria-label="제목 수정"], [aria-label="제목 편집"], [aria-label="설명 수정"]'));
  const readMenu = () => [...document.querySelectorAll(youtubeDom.menu)].filter(visible);
  const buttons = [...(header?.querySelectorAll(youtubeDom.buttons) || [])].filter(visible);
  if (!editable && buttons.length === 1 && !readMenu().length) {
    buttons[0].click();
    for (let attempt = 0; attempt < 8 && key() === expectedSource; attempt++) {
      const menu = readMenu();
      if (menu.length) {
        editable = menu.some((entry) => /^(delete playlist|재생목록 삭제)$/i.test((entry.textContent || '').trim()));
        header.click();
        break;
      }
      await wait(150);
    }
  }
  return key() === expectedSource && label && label !== 'YouTube' ? { label, editable } : null;
}

export async function savePlaylistVideo(itemUrl, destination, youtubeDom) {
  const target = new URL(itemUrl);
  const onTarget = () => location.origin === 'https://www.youtube.com' && location.pathname === '/watch' &&
    new URLSearchParams(location.search).get('v') === target.searchParams.get('v');
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const normalized = (value) => (value || '').normalize('NFKC').trim().replace(/\s+/g, ' ').toLowerCase();
  const usable = (element) => element?.getClientRects().length &&
    !element.closest('[hidden], [aria-hidden="true"], [aria-disabled="true"], [inert], :disabled') &&
    getComputedStyle(element).visibility === 'visible';
  const matches = (element, regex) =>
    [element.getAttribute('aria-label'), element.textContent].some((value) => regex.test(normalized(value)));
  const saveLabel = /^(save|save to playlist|저장|재생목록에 저장)$/;
  const readMenu = () => [...document.querySelectorAll(youtubeDom.menu)].filter(usable);
  const optionsSelector = 'ytd-playlist-add-to-option-renderer, [role="checkbox"], input[type="checkbox"], tp-yt-paper-checkbox, yt-list-item-view-model';
  const dialogSelector = 'ytd-add-to-playlist-renderer, [role="dialog"], yt-sheet-view-model, yt-contextual-sheet-layout';
  const readOptions = () => [...document.querySelectorAll(`:is(${dialogSelector}) :is(${optionsSelector})`)]
    .filter(usable).filter((entry) => !entry.parentElement.closest(optionsSelector));

  if (!onTarget()) return 'missing';
  let opened = false;
  for (let attempt = 0; attempt < 16 && onTarget(); attempt++) {
    document.querySelector('video')?.pause();
    const actions = [...document.querySelectorAll('ytd-watch-metadata button, ytd-video-primary-info-renderer #menu button')].filter(usable);
    const direct = actions.filter((button) => matches(button, saveLabel));
    if (direct.length === 1 && !readMenu().length && !readOptions().length) {
      direct[0].click();
      opened = true;
      break;
    }
    const more = actions.filter((button) => matches(button, /^(action menu|more actions|more|더보기|더 보기|작업 메뉴)$/));
    if (more.length === 1 && !readMenu().length && !readOptions().length) {
      more[0].click();
      for (let check = 0; check < 10 && onTarget(); check++) {
        const menu = readMenu();
        const matchesSave = menu.filter((entry) => matches(entry, saveLabel));
        const leaves = matchesSave.filter((entry) => !matchesSave.some((other) => entry !== other && entry.contains(other)));
        if (leaves.length === 1) {
          const [entry] = leaves;
          (entry.querySelector('button, tp-yt-paper-item, [role="button"]') || entry).click();
          opened = true;
          break;
        }
        await wait(175);
      }
      break;
    }
    await wait(250);
  }
  if (!opened) return 'save-unavailable';

  const playlistId = new URL(destination.key).searchParams.get('list');
  const labels = [normalized(destination.label)];
  if (playlistId === 'WL') labels.push('watch later', '나중에 볼 동영상', '나중에 볼 영상');
  for (let attempt = 0; attempt < 15 && onTarget(); attempt++) {
    const options = readOptions().map((entry) => {
      const control = entry.matches('[role="checkbox"], input[type="checkbox"], tp-yt-paper-checkbox') ? entry
        : entry.querySelector('[role="checkbox"], input[type="checkbox"], tp-yt-paper-checkbox');
      const id = entry.getAttribute('data-playlist-id') || control?.getAttribute('data-playlist-id') ||
        (entry.querySelector('a[href*="list="]') && new URL(entry.querySelector('a[href*="list="]').href).searchParams.get('list'));
      const label = entry.querySelector('#label, #title, .ytListItemViewModelTitle, .yt-list-item-view-model__title')?.textContent ||
        control?.getAttribute('aria-label') || entry.textContent;
      return { control, id, label: normalized(label) };
    }).filter(({ control }) => control && usable(control));
    const exact = options.filter(({ id }) => id === playlistId);
    const byName = options.filter(({ label }) => labels.includes(label));
    const candidates = exact.length ? exact : destination.editable && byName.length === 1 && !byName[0].id ? byName : [];
    if (exact.length > 1 || (!exact.length && byName.length > 1)) return 'ambiguous';
    if (candidates.length === 1) {
      const { control } = candidates[0];
      const state = control.getAttribute('aria-checked');
      if (control.checked === true || state === 'true' || control.hasAttribute('checked')) return 'present';
      if (control.checked !== false && state !== 'false') return 'unknown';
      control.click();
      await wait(500);
      return 'attempted';
    }
    await wait(200);
  }
  return 'destination-unavailable';
}

export async function readInstagramMetadata(postUrl, expectedSource) {
  const post = new URL(postUrl);
  const origin = 'https://www.instagram.com';
  const path = (url) => url.pathname.replace(/\/$/, '');
  const findPostId = (url) => path(url).match(/^\/(?:p|reel|tv)\/([\w-]+)$/)?.[1];
  const postId = findPostId(post);
  if (post.origin !== origin || !postId ||
      (location.origin + path(location)).toLowerCase() !== expectedSource) return null;

  const response = await fetch(post, {
    credentials: 'same-origin',
    redirect: 'error',
    referrerPolicy: 'no-referrer',
    signal: AbortSignal.timeout(5000),
  });
  if (!response.ok) return null;
  const head = (await response.text()).match(/<head(?:\s[^>]*)?>[\s\S]*?<\/head\s*>/i)?.[0];
  if (!head) return null;
  const document = new DOMParser().parseFromString(head, 'text/html');
  const meta = (property) => document.querySelector(`meta[property="${property}"]`)?.getAttribute('content')?.trim();
  const canonical = meta('og:url') || document.querySelector('link[rel="canonical"]')?.getAttribute('href');
  if (!canonical || !URL.canParse(canonical, origin)) return null;
  const canonicalUrl = new URL(canonical, origin);
  if (canonicalUrl.origin !== origin || findPostId(canonicalUrl) !== postId) return null;

  const title = meta('og:title') || '';
  const description = meta('og:description') || '';
  const authorAndCaption = /^(.*?)\s+on Instagram\s*:\s*([\s\S]*)$/i;
  const titleParts = title.match(authorAndCaption) || title.match(/^Instagram의\s+(.+?)님\s*[:：]\s*([\s\S]*)$/);
  const descriptionParts = description.replace(/^.*?\s[-–]\s(?=.*\son Instagram\s*:)/i, '').match(authorAndCaption);
  const caption = (titleParts?.[2] || descriptionParts?.[2] || description).replace(/^[“"‘]|[”"’]$/g, '').trim();
  const author = titleParts?.[1]?.trim() || descriptionParts?.[1]?.trim();
  const thumbnail = meta('og:image:secure_url') || meta('og:image');
  const plainTitle = /^instagram$/i.test(title) ? '' : title;
  return { title: caption || plainTitle || meta('og:image:alt'), channel: author, description: caption, thumbnail };
}

export async function readOrRemove(platform, itemUrl, remove) {
  const target = new URL(itemUrl);
  const isYouTube = platform === 'youtube';
  const onTarget = () => location.origin === target.origin && (isYouTube
    ? location.pathname === '/watch' && new URLSearchParams(location.search).get('v') === target.searchParams.get('v')
    : location.pathname.replace(/\/$/, '') === target.pathname.replace(/\/$/, ''));
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const usable = (element) => element?.getClientRects().length &&
    !element.closest('[hidden], [aria-hidden="true"], [inert], [aria-disabled="true"], :disabled') &&
    getComputedStyle(element).visibility === 'visible';

  const youtubeState = () => {
    const buttons = [...document.querySelectorAll(
      'ytd-watch-metadata like-button-view-model button[aria-pressed], ' +
      'ytd-watch-metadata #segmented-like-button button[aria-pressed], ' +
      'ytd-video-primary-info-renderer #segmented-like-button button[aria-pressed]'
    )].filter(usable);
    if (buttons.length !== 1) return null;
    const button = buttons[0];
    const pressed = button.getAttribute('aria-pressed');
    if (pressed === 'true' || pressed === 'false') return { button, saved: pressed === 'true' };
    return null;
  };

  const instagramState = () => {
    const active = ['remove from saved', 'remove from saved posts', 'unsave', '저장 취소', '저장 해제', '저장 삭제', '저장됨에서 삭제'];
    const inactive = ['save', 'save post', '저장', '저장하기'];
    const root = document.querySelector('main, [role="main"]') || document.querySelector('article');
    if (!root) return null;
    const controls = new Map();
    for (const icon of root.querySelectorAll('svg[aria-label]')) {
      const label = icon.getAttribute('aria-label').trim().toLowerCase();
      const filledBookmark = [...icon.querySelectorAll('path')].some((path) =>
        /^M23\s*23\s*l-11[\s,]*-7\.72/i.test(path.getAttribute('d') || ''));
      const saved = active.includes(label) || (['remove', '삭제'].includes(label) && filledBookmark);
      if (!saved && !inactive.includes(label)) continue;
      const button = icon.closest('button, [role="button"]');
      if (usable(button) && !button.closest('header, nav, [role="dialog"]')) controls.set(button, saved);
    }
    if (controls.size !== 1) return null;
    const [[button, saved]] = controls;
    return { button, saved };
  };

  let previous;
  for (let attempt = 0; attempt < 16; attempt++) {
    if (!onTarget()) return 'wrong-page';
    const state = isYouTube ? youtubeState() : instagramState();
    if (isYouTube) document.querySelector('video')?.pause();
    if (state && previous?.button === state.button && previous.saved === state.saved) {
      if (!state.saved) return 'clear';
      if (!remove) return 'still-saved';
      state.button.click();
      // Allow the site to finish its own request before the caller reloads to verify.
      await wait(1100);
      return 'clicked';
    }
    previous = state;
    await wait(350);
  }
  return 'unknown';
}
