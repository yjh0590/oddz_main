import { platforms, sourceKey, youtubeListDom, readList, readInstagramMetadata, readOrRemove,
  removePlaylistVideo, inspectPlaylistDestination, savePlaylistVideo } from './sites.js';
import { itemCategory, otherCategory } from './categories.js';
import { findDuplicateBookmarks, sameBookmark } from './bookmarks.js';
import { historyCsv, readHistory, saveHistory } from './history.js';

const $ = (id) => document.getElementById(id);
const platformButtons = [...document.querySelectorAll('[data-platform]')];
const sourceSelect = $('source-tab');
const dialog = $('confirm');
const selectAll = $('select-all');
const groupItems = $('group-items');
const collectionSelect = $('collection-select');
const cleanupButton = $('select-cleanup');
const itemSearch = $('item-search');
const itemFilter = $('item-filter');
const destinationSelect = $('destination');
const bookmarkDialog = $('bookmark-confirm');
const youtubeVideoUrl = 'https://www.youtube.com/watch?';
const items = new Map();
const selected = new Set();
const completedBySource = new Map();
const metadataLookups = new Map();
let successCount = 0;
let failureCount = 0;
let platform = 'youtube';
let source;
let busy = false;
let running = false;
let grouped = false;
let groupingFrame = 0;
let activeScan;
let reviewContext;
let bookmarks = [];
let bookmarkPlan = [];
let savedHistory = [];

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type === 'list-scan-progress' && activeScan &&
      message.scanId === activeScan.id && sender.tab?.id === activeScan.tabId) {
    status(`목록을 불러오는 중입니다. 지금까지 ${message.count}개를 찾았습니다.`);
  }
});

function status(message, error = false) {
  $('status').textContent = message;
  $('status').dataset.error = String(error);
}

function syncControls() {
  for (const button of platformButtons) button.disabled = busy;
  for (const id of ['refresh-tabs', 'load', 'source-tab', 'review', 'find-bookmarks']) $(id).disabled = busy;
  sourceSelect.disabled ||= !sourceSelect.options.length || !sourceSelect.value;
  $('load').disabled ||= !sourceSelect.value;
  $('review').disabled ||= !selected.size;
  $('move').disabled = busy || ![...selected].some((id) => items.get(id)?.video && !items.get(id).unavailable);
  itemSearch.disabled = busy;
  itemFilter.disabled = busy;
  groupItems.disabled = busy || !items.size;
  cleanupButton.disabled = busy;
  $('review-bookmarks').disabled = busy || !chosenBookmarkGroups().length;
  collectionSelect.disabled = busy || !sourceSelect.value;
  $('load-collections').disabled = busy || !sourceSelect.value;
  for (const checkbox of $('items').querySelectorAll('input')) checkbox.disabled = busy;
  applyItemFilters();
}

function applyItemFilters() {
  const query = itemSearch.value.normalize('NFKC').trim().toLowerCase().split(/\s+/).filter(Boolean);
  const mode = itemFilter.value;
  let shown = 0;
  let checked = 0;
  for (const row of $('items').querySelectorAll('.item-row')) {
    const item = items.get(row.dataset.id);
    const text = [item.title, item.channel, item.description].join(' ').normalize('NFKC').toLowerCase();
    const selectedHere = selected.has(item.id);
    row.hidden = !query.every((word) => text.includes(word)) ||
      (mode === 'duplicate' && !item.duplicate) ||
      (mode === 'unavailable' && !item.unavailable) ||
      (mode === 'selected' && !selectedHere);
    if (row.hidden) continue;
    shown++;
    if (selectedHere) checked++;
  }
  for (const group of $('items').querySelectorAll('.category-group')) {
    group.hidden = !group.querySelector('.item-row:not([hidden])');
  }
  selectAll.disabled = busy || !shown;
  selectAll.checked = shown > 0 && shown === checked;
  selectAll.indeterminate = checked > 0 && checked < shown;
  $('filter-empty').hidden = !items.size || shown > 0;
  const count = shown === items.size ? `${shown}개` : `${shown}개 표시 · 전체 ${items.size}개`;
  $('item-count').textContent = `${count} · ${selected.size}개 선택`;
}

function setBusy(value) {
  busy = value;
  syncControls();
}

function linkToItem(item, text) {
  const link = document.createElement('a');
  link.href = item.url;
  link.target = '_blank';
  link.rel = 'noopener noreferrer';
  link.textContent = text;
  return link;
}

function itemTitle(item) {
  const kind = item.url.startsWith(youtubeVideoUrl) ? '동영상' : '게시물';
  return item.title || `${kind} · ${item.video || item.id}`;
}

function thumbnailUrl(value) {
  if (!value || !URL.canParse(value)) return '';
  const url = new URL(value);
  const host = url.hostname;
  return url.protocol === 'https:' &&
    (host.endsWith('.ytimg.com') || host.endsWith('.cdninstagram.com') || host.endsWith('.fbcdn.net'))
    ? url.href : '';
}

function thumbnail(item, onUnavailable) {
  const placeholder = document.createElement('span');
  placeholder.className = 'thumbnail';
  const fallback = item.url.startsWith(youtubeVideoUrl)
    ? 'https://i.ytimg.com/vi/' + item.video + '/hqdefault.jpg'
    : '';
  const sourceUrl = thumbnailUrl(item.thumbnail) || fallback;
  if (!sourceUrl) return placeholder;
  const image = document.createElement('img');
  image.alt = '';
  image.loading = 'lazy';
  image.referrerPolicy = 'no-referrer';
  image.addEventListener('error', () => {
    if (fallback && image.src !== fallback) image.src = fallback;
    else {
      image.replaceWith(placeholder);
      onUnavailable?.();
    }
  });
  image.src = sourceUrl;
  return image;
}

async function fetchYouTubeMetadata(url) {
  try {
    const endpoint = new URL('https://www.youtube.com/oembed');
    endpoint.search = new URLSearchParams({ url, format: 'json' });
    const response = await fetch(endpoint, {
      credentials: 'omit',
      redirect: 'error',
      referrerPolicy: 'no-referrer',
      signal: AbortSignal.timeout(5000),
    });
    if (response.ok) {
      const data = await response.json();
      return { title: data.title, channel: data.author_name };
    }
  } catch {
    // The playlist and thumbnail can still be displayed if metadata is unavailable.
  }
  return null;
}

function updateItemText(row, item) {
  const title = itemTitle(item);
  const titleElement = row.querySelector('.item-title');
  const detail = row.querySelector('.item-detail');
  titleElement.textContent = title;
  titleElement.title = title;
  detail.textContent = [item.channel, item.description === title ? '' : item.description].filter(Boolean).join(' · ');
  detail.hidden = !detail.textContent;
  row.querySelector('.site-link')?.setAttribute('aria-label', title + ' 원본 보기');
}

function markCleanupCandidates() {
  const videos = new Map();
  for (const item of items.values()) {
    item.duplicate = false;
    item.cleanup = Boolean(item.unavailable);
    if (!item.video) continue;
    if (!videos.has(item.video)) videos.set(item.video, []);
    videos.get(item.video).push(item);
  }
  for (const copies of videos.values()) {
    if (copies.length < 2) continue;
    const keep = copies.find((item) => !item.unavailable);
    for (const item of copies) {
      item.duplicate = true;
      item.cleanup ||= item !== keep;
    }
  }
  cleanupButton.hidden = ![...items.values()].some((item) => item.cleanup);
}

function arrangeItems() {
  const list = $('items');
  const focused = list.contains(document.activeElement) ? document.activeElement : null;
  const rowsById = new Map([...list.querySelectorAll('.item-row')].map((row) => [row.dataset.id, row]));
  const orderedRows = [...items.keys()].map((id) => rowsById.get(id)).filter(Boolean);
  if (!grouped) {
    list.replaceChildren(...orderedRows);
  } else {
    const categories = new Map();
    for (const row of orderedRows) {
      const name = itemCategory(items.get(row.dataset.id));
      if (!categories.has(name)) categories.set(name, []);
      categories.get(name).push(row);
    }
    const other = categories.get(otherCategory);
    if (other) {
      categories.delete(otherCategory);
      categories.set(otherCategory, other);
    }
    const groups = document.createDocumentFragment();
    for (const [name, rows] of categories) {
      const group = document.createElement('li');
      group.className = 'category-group';
      const heading = document.createElement('h3');
      heading.className = 'category-heading';
      const count = document.createElement('span');
      count.className = 'category-count';
      count.textContent = `${rows.length}개`;
      heading.append(name, ' ', count);
      const categoryList = document.createElement('ul');
      categoryList.className = 'category-items';
      categoryList.append(...rows);
      group.append(heading, categoryList);
      groups.append(group);
    }
    list.replaceChildren(groups);
  }
  focused?.focus({ preventScroll: true });
  applyItemFilters();
}

function scheduleGrouping() {
  if (groupingFrame) return;
  groupingFrame = requestAnimationFrame(() => {
    groupingFrame = 0;
    if (grouped) arrangeItems();
  });
}

const metadataObserver = new IntersectionObserver((entries) => {
  for (const { target: row, isIntersecting } of entries) {
    if (!isIntersecting) continue;
    metadataObserver.unobserve(row);
    const item = items.get(row.dataset.id);
    if (!row.isConnected || !item || !source) continue;
    const isYouTube = item.url.startsWith(youtubeVideoUrl);
    if (!metadataLookups.has(item.url)) {
      const request = isYouTube
        ? fetchYouTubeMetadata(item.url)
        : inject(source.id, readInstagramMetadata, item.url, source.key).catch(() => null);
      metadataLookups.set(item.url, request);
    }
    const lookup = metadataLookups.get(item.url);
    void lookup.then((metadata) => {
      if (!metadata || !row.isConnected || items.get(item.id) !== item) return;
      const previousCategory = grouped ? itemCategory(item) : null;
      if (typeof metadata.title === 'string' && (!item.title || (!isYouTube && !item.description))) {
        item.title = metadata.title.trim() || item.title;
      }
      if (!item.channel && typeof metadata.channel === 'string') item.channel = metadata.channel.trim();
      item.description ||= metadata.description;
      const placeholder = row.querySelector('label > .thumbnail');
      if (placeholder && thumbnailUrl(metadata.thumbnail)) {
        item.thumbnail = metadata.thumbnail;
        placeholder.replaceWith(thumbnail(item));
      }
      updateItemText(row, item);
      if (itemSearch.value) applyItemFilters();
      if (grouped && previousCategory !== itemCategory(item)) scheduleGrouping();
    });
  }
});

function renderItems() {
  metadataObserver.disconnect();
  markCleanupCandidates();
  const rows = document.createDocumentFragment();
  for (const item of items.values()) {
    const row = document.createElement('li');
    row.className = 'item-row';
    row.dataset.id = item.id;
    const label = document.createElement('label');
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.value = item.id;
    checkbox.checked = selected.has(item.id);
    const title = document.createElement('span');
    title.className = 'item-title';
    const detail = document.createElement('span');
    detail.className = 'item-detail';
    const text = document.createElement('span');
    text.className = 'item-text';
    text.append(title, detail);
    if (item.unavailable || item.duplicate) {
      const issue = document.createElement('span');
      issue.className = 'item-issue';
      issue.textContent = [item.duplicate ? '중복' : '', item.unavailable ? '시청 불가' : ''].filter(Boolean).join(' · ');
      text.append(issue);
    }
    const retryThumbnail = platform === 'instagram' ? () => {
      if (row.isConnected) metadataObserver.observe(row);
    } : undefined;
    label.append(checkbox, thumbnail(item, retryThumbnail), text);
    row.append(label);
    if (item.url) {
      const link = linkToItem(item, '원본 보기');
      link.className = 'site-link';
      row.append(link);
    }
    updateItemText(row, item);
    rows.append(row);
    const needsMetadata = platform !== 'instagram'
      ? !item.title
      : !item.title || !item.description || !thumbnailUrl(item.thumbnail);
    if (needsMetadata && item.url && !item.unavailable) metadataObserver.observe(row);
  }
  $('items').replaceChildren(rows);
  if (grouped) arrangeItems();
  $('items-panel').hidden = !items.size;
  syncControls();
}

function resetList() {
  source = null;
  items.clear();
  selected.clear();
  metadataLookups.clear();
  renderItems();
}

async function refreshTabs() {
  setBusy(true);
  try {
    const active = sourceSelect.value;
    const tabs = await chrome.tabs.query({ url: platforms[platform].pattern });
    const options = tabs
      .filter((tab) => sourceKey(platform, tab.url))
      .map((tab) => new Option(tab.title || tab.url, String(tab.id)));
    if (!options.length) options.push(new Option('열려 있는 목록 탭이 없습니다', ''));
    sourceSelect.replaceChildren(...options);
    if (options.some((option) => option.value === active)) sourceSelect.value = active;
    if (source && String(source.id) !== sourceSelect.value) resetList();
    if (sourceSelect.value !== active) resetCollections();
    if (options[0].value && !source) status('목록을 불러올 탭을 선택하세요.');
    if (!options[0].value) status('사이트에서 목록을 연 다음 탭을 새로고침하세요.');
  } catch {
    sourceSelect.replaceChildren();
    resetList();
    status('열린 탭을 확인할 수 없습니다. 확장 프로그램의 사이트 액세스 설정을 확인하세요.', true);
  } finally {
    setBusy(false);
  }
}

async function choosePlatform(next) {
  platform = next;
  document.documentElement.dataset.theme = next === 'instagram' ? 'instagram' : 'youtube';
  resetList();
  sourceSelect.replaceChildren();
  for (const button of platformButtons) button.setAttribute('aria-pressed', String(button.dataset.platform === next));
  const isBookmarks = next === 'bookmarks';
  const isHistory = next === 'history';
  $('social-panel').hidden = isBookmarks || isHistory;
  $('bookmarks-panel').hidden = !isBookmarks;
  $('history-panel').hidden = !isHistory;
  $('results-panel').hidden = isBookmarks || isHistory || (successCount + failureCount === 0);
  document.querySelector('.library').setAttribute('aria-labelledby',
    isBookmarks ? 'bookmarks-title' : isHistory ? 'history-title' : 'library-title');
  $('collection-controls').hidden = next !== 'instagram';
  $('move').hidden = next !== 'youtube-playlist';
  itemSearch.value = '';
  itemFilter.value = 'all';
  for (const option of itemFilter.querySelectorAll('.video-filter')) option.hidden = next === 'instagram';
  resetCollections();
  if (isHistory) {
    await showHistory();
    return;
  }
  if (isBookmarks) {
    syncControls();
    return;
  }
  const site = platforms[next];
  $('library-title').textContent = site.title;
  $('source-link').textContent = site.openLabel;
  $('source-link').href = site.home;
  $('source-help').textContent = site.help;
  await refreshTabs();
}

async function inject(tabId, func, ...args) {
  const [frame] = await chrome.scripting.executeScript({
    target: { tabId },
    func,
    args,
  });
  if (!frame || frame.error || frame.result === undefined) throw new Error('사이트에서 응답을 받지 못했습니다.');
  return frame.result;
}

async function sourceTabContext(tab) {
  return { tabId: tab.id, windowId: tab.windowId, dashboardTab: await chrome.tabs.getCurrent() };
}

async function showSourceTab({ tabId, windowId, dashboardTab }) {
  await chrome.tabs.update(tabId, { active: true });
  if (dashboardTab?.windowId !== windowId) await chrome.windows.update(windowId, { focused: true });
}

async function returnToDashboard({ dashboardTab, tabId, windowId }) {
  if (!dashboardTab?.id) return;
  try {
    const [sourceTab, activeWindow] = await Promise.all([
      chrome.tabs.get(tabId),
      chrome.windows.getLastFocused(),
    ]);
    if (!sourceTab.active || activeWindow.id !== windowId) return;
    await chrome.tabs.update(dashboardTab.id, { active: true });
    if (dashboardTab.windowId !== windowId) await chrome.windows.update(dashboardTab.windowId, { focused: true });
  } catch {
    // The user may close either tab while the operation is running.
  }
}

function resetCollections() {
  collectionSelect.replaceChildren(new Option('모든 게시물', ''));
}

async function openInstagramList(tab, url) {
  const key = sourceKey('instagram', url);
  if (sourceKey('instagram', tab.url) !== key) {
    await loadWorkPage(tab.id, () => chrome.tabs.update(tab.id, { url }));
    if (sourceKey('instagram', (await chrome.tabs.get(tab.id)).url) !== key) {
      throw new Error('이 Instagram 목록을 열 수 없습니다. 로그인 상태를 확인하세요.');
    }
  }
  return key;
}

async function loadCollections() {
  if (busy || !sourceSelect.value) return;
  setBusy(true);
  status('Instagram 컬렉션을 찾는 중입니다.');
  try {
    const tab = await chrome.tabs.get(Number(sourceSelect.value));
    const key = sourceKey('instagram', tab.url);
    if (!key) throw new Error('Instagram 저장됨 탭을 열고 다시 선택하세요.');
    const index = key.replace(/\/saved(?:\/.*)?$/, '/saved');
    const current = collectionSelect.value;
    resetList();
    activeScan = { ...await sourceTabContext(tab), id: crypto.randomUUID() };
    await showSourceTab(activeScan);
    await openInstagramList(tab, index + '/');
    const response = await inject(tab.id, readList, 'instagram', index, activeScan.id, youtubeListDom, true);
    if (response.changed) throw new Error('Instagram 탭이 바뀌었습니다. 컬렉션을 다시 찾아 주세요.');
    resetCollections();
    for (const entry of response.items) collectionSelect.add(new Option(entry.title, entry.url));
    if ([...collectionSelect.options].some((option) => option.value === current)) collectionSelect.value = current;
    status(response.incomplete
      ? `컬렉션 ${response.items.length}개를 찾았습니다. 목록 끝까지 확인하지 못했습니다. 다시 시도할 수 있습니다.`
      : response.items.length ? `컬렉션 ${response.items.length}개를 찾았습니다. 컬렉션을 고르고 목록을 불러오세요.`
      : '표시할 컬렉션이 없습니다.');
  } catch (error) {
    status(error.message || '컬렉션을 불러오지 못했습니다.', true);
  } finally {
    if (activeScan) await returnToDashboard(activeScan);
    activeScan = undefined;
    setBusy(false);
  }
}

async function loadList() {
  if (busy || !sourceSelect.value) return;
  setBusy(true);
  status('목록을 불러오는 중입니다.');
  try {
    const tab = await chrome.tabs.get(Number(sourceSelect.value));
    let key = sourceKey(platform, tab.url);
    if (!key) throw new Error('선택한 탭에서 원본 목록을 다시 열어 주세요.');
    resetList();
    activeScan = { ...await sourceTabContext(tab), id: crypto.randomUUID() };
    await showSourceTab(activeScan);
    if (platform === 'instagram') {
      const index = key.replace(/\/saved(?:\/.*)?$/, '/saved');
      const collection = collectionSelect.value;
      const collectionKey = collection && sourceKey(platform, collection);
      const wanted = collectionKey?.startsWith(index + '/') ? collection : index + '/all-posts/';
      key = await openInstagramList(tab, wanted);
    }
    const response = await inject(tab.id, readList, platform, key, activeScan.id, youtubeListDom);
    if (response.changed) throw new Error('원본 탭의 페이지가 바뀌었습니다. 목록을 다시 열어 주세요.');
    const label = platform === 'instagram' ? collectionSelect.selectedOptions[0]?.textContent
      : tab.title?.replace(/\s*[-–]\s*YouTube\s*$/i, '');
    source = { id: tab.id, key, label: label || platforms[platform].title };
    const excluded = platform === 'youtube-playlist' ? null : completedBySource.get(key);
    for (const item of response.items) {
      if (!excluded?.has(item.video || item.id)) items.set(item.id, item);
    }
    if (response.incomplete) {
      status(`${items.size}개를 불러왔습니다. 목록 끝까지 확인하지 못했습니다. 목록 불러오기를 눌러 다시 시도하세요.`, true);
    } else if (!items.size) {
      status('표시할 항목이 없습니다. 사이트에서 로그인 상태와 목록을 확인하세요.');
    } else {
      status(`${items.size}개를 불러왔습니다.`);
    }
    renderItems();
  } catch (error) {
    status(error.message || '목록을 불러오지 못했습니다.', true);
  } finally {
    if (activeScan) await returnToDashboard(activeScan);
    activeScan = undefined;
    setBusy(false);
  }
}

function showReview() {
  const queue = [...items.values()].filter((item) => selected.has(item.id));
  if (busy || !queue.length || !source) return;
  const site = platforms[platform];
  $('destination-control').hidden = true;
  $('run').disabled = false;
  $('confirm-message').textContent = platform === 'youtube-playlist'
    ? `‘${source.label}’ 재생목록에서 아래 ${queue.length}개 영상을 제거합니다.`
    : platform === 'instagram'
      ? `Instagram에서 아래 ${queue.length}개 게시물의 저장을 해제합니다.`
      : `아래 ${queue.length}개 영상의 YouTube 좋아요를 취소합니다.`;
  $('run').textContent = `${queue.length}개 ${site.action}`;
  $('confirm-items').replaceChildren(...queue.map((item) => {
    const row = document.createElement('li');
    row.textContent = itemTitle(item);
    return row;
  }));
  reviewContext = { platform, source, queue };
  dialog.showModal();
}

async function showMoveReview() {
  if (busy || !source || platform !== 'youtube-playlist') return;
  const queue = [...items.values()].filter((item) => selected.has(item.id));
  if (!queue.some((item) => item.video && !item.unavailable)) return;
  setBusy(true);
  try {
    const tabs = await chrome.tabs.query({ url: platforms['youtube-playlist'].pattern });
    const targets = new Map();
    for (const tab of tabs) {
      const key = sourceKey('youtube-playlist', tab.url);
      if (!key || key === source.key || targets.has(key)) continue;
      const label = tab.title?.replace(/\s*[-–]\s*YouTube\s*$/i, '')?.trim();
      if (label && label !== 'YouTube') targets.set(key, { id: tab.id, key, label });
    }
    if (!targets.size) {
      status('이동할 재생목록을 다른 YouTube 탭에 열고 다시 시도하세요.');
      return;
    }
    destinationSelect.replaceChildren(new Option('대상 재생목록을 선택하세요', ''));
    for (const target of targets.values()) destinationSelect.add(new Option(target.label, target.key));
    $('destination-control').hidden = false;
    $('confirm-message').textContent = `‘${source.label}’의 선택 항목을 이동합니다. 대상에서 확인된 영상만 원래 목록에서 제거합니다.`;
    $('run').textContent = '재생목록으로 이동';
    $('run').disabled = true;
    $('confirm-items').replaceChildren(...queue.map((item) => {
      const row = document.createElement('li');
      row.textContent = itemTitle(item);
      return row;
    }));
    reviewContext = { platform, source, queue, targets };
    dialog.showModal();
  } catch {
    status('이동할 재생목록을 확인하지 못했습니다.', true);
  } finally {
    setBusy(false);
  }
}

async function showHistory() {
  setBusy(true);
  const message = $('history-status');
  const results = $('history-results');
  results.replaceChildren();
  $('export-history').disabled = true;
  try {
    savedHistory = await readHistory();
    const fragment = document.createDocumentFragment();
    const dates = new Intl.DateTimeFormat('ko-KR', { dateStyle: 'medium', timeStyle: 'short' });
    for (const entry of savedHistory) {
      const row = document.createElement('li');
      const title = entry.url ? linkToItem(entry, entry.title) : document.createTextNode(entry.title);
      const details = document.createElement('div');
      details.className = 'history-detail';
      const route = entry.destination ? `${entry.source} → ${entry.destination}` : entry.source;
      details.textContent = [dates.format(new Date(entry.at)), entry.site, entry.action, route].filter(Boolean).join(' · ');
      row.append(title, details);
      fragment.append(row);
    }
    results.append(fragment);
    message.textContent = savedHistory.length ? `${savedHistory.length}개 작업이 기록되어 있습니다.` : '기록된 정리 작업이 없습니다.';
    $('export-history').disabled = !savedHistory.length;
  } catch {
    savedHistory = [];
    message.textContent = '정리 내역을 불러오지 못했습니다.';
  } finally {
    setBusy(false);
  }
}

function exportHistory() {
  if (!savedHistory.length) return;
  const url = URL.createObjectURL(new Blob([historyCsv(savedHistory)], { type: 'text/csv;charset=utf-8' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = 'social-saves-history.csv';
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function loadWorkPage(tabId, navigate) {
  let cleanup;
  const pageLoaded = new Promise((resolve, reject) => {
    const onUpdated = (id, change, tab) => {
      if (id === tabId && change.status === 'complete' && tab.url && tab.url !== 'about:blank') resolve();
    };
    const onRemoved = (id) => {
      if (id === tabId) reject(new Error('작업 탭이 닫혔습니다.'));
    };
    const timer = setTimeout(() => reject(new Error('작업 페이지가 제시간에 열리지 않았습니다.')), 20000);
    cleanup = () => {
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      chrome.tabs.onRemoved.removeListener(onRemoved);
    };
    chrome.tabs.onUpdated.addListener(onUpdated);
    chrome.tabs.onRemoved.addListener(onRemoved);
  });
  try {
    await Promise.all([pageLoaded, navigate()]);
  } finally {
    cleanup();
  }
}

async function processItem(tabId, item, site) {
  await loadWorkPage(tabId, () => chrome.tabs.update(tabId, { url: item.url }));
  const first = await inject(tabId, readOrRemove, site, item.url, true);
  if (first === 'clear') return '이미 해제된 상태입니다.';
  if (first === 'wrong-page') throw new Error('원본 게시물을 열 수 없습니다. 로그인 상태나 게시물 공개 범위를 확인하세요.');
  if (first !== 'clicked') throw new Error('해제 버튼을 확인할 수 없습니다. 원본 페이지를 확인하세요.');

  await loadWorkPage(tabId, () => chrome.tabs.reload(tabId));
  const verified = await inject(tabId, readOrRemove, site, item.url, false);
  if (verified !== 'clear') throw new Error('페이지를 다시 열었지만 해제 상태를 확인하지 못했습니다.');
  return platforms[site].done;
}

async function processPlaylistItem(source, item) {
  const result = await inject(source.id, removePlaylistVideo, source.key, item, youtubeListDom);
  if (result === 'removed') return platforms['youtube-playlist'].done;
  const messages = {
    'wrong-page': '원본 재생목록이 바뀌었거나 다른 화면에서 다시 불러왔습니다. 목록을 다시 불러오세요.',
    duplicate: '선택한 항목의 위치를 정확히 확인할 수 없습니다. 목록을 다시 불러오세요.',
    missing: '원본 재생목록에서 이 영상을 찾지 못했습니다.',
    'menu-open': 'YouTube에서 열린 메뉴를 닫고 다시 시도하세요.',
    'menu-unavailable': '재생목록에서 제거하는 메뉴를 확인할 수 없습니다. 수정 권한을 확인하세요.',
    unverified: '제거를 요청했지만 재생목록에서 영상이 사라졌는지 확인하지 못했습니다.',
  };
  throw new Error(messages[result] || '재생목록에서 영상을 제거하지 못했습니다.');
}

async function preparePlaylistMove(context, workTabId) {
  const sourceInfo = await inject(context.source.id, inspectPlaylistDestination, context.source.key, youtubeListDom);
  if (!sourceInfo?.editable) throw new Error('원본 재생목록의 수정 권한을 확인할 수 없습니다.');
  const target = context.destination;
  const tab = await chrome.tabs.get(target.id);
  if (sourceKey('youtube-playlist', tab.url) !== target.key) throw new Error('대상 재생목록 탭이 바뀌었습니다.');
  const targetInfo = await inject(target.id, inspectPlaylistDestination, target.key, youtubeListDom);
  if (!targetInfo || targetInfo.label !== target.label) {
    throw new Error('대상 재생목록의 이름을 확인할 수 없습니다. 목록을 다시 선택하세요.');
  }
  await showSourceTab(await sourceTabContext(await chrome.tabs.get(workTabId)));
  const attempts = new Map();
  for (const item of context.queue) {
    if (!item.video || item.unavailable || attempts.has(item.video)) continue;
    status(`대상 재생목록에 추가하는 중입니다 · ${attempts.size + 1}번째 영상`);
    try {
      await loadWorkPage(workTabId, () => chrome.tabs.update(workTabId, { url: item.url }));
      attempts.set(item.video, await inject(workTabId, savePlaylistVideo, item.url, { ...target, ...targetInfo }, youtubeListDom));
    } catch {
      attempts.set(item.video, 'save-unavailable');
    }
  }
  const canVerify = [...attempts.values()].some((result) => result === 'attempted' || result === 'present');
  const verified = new Set();
  if (canVerify) {
    status('대상 재생목록에서 영상을 확인하는 중입니다.');
    try {
      if (sourceKey('youtube-playlist', (await chrome.tabs.get(target.id)).url) !== target.key) return { attempts, verified };
      await showSourceTab(await sourceTabContext(tab));
      await loadWorkPage(target.id, () => chrome.tabs.reload(target.id));
      const result = await inject(target.id, readList, 'youtube-playlist', target.key, crypto.randomUUID(), youtubeListDom);
      if (!result.changed) {
        for (const item of result.items) if (item.video) verified.add(item.video);
      }
    } catch {
      // Until the destination is verified, the original entries are kept.
    }
  }
  return { attempts, verified };
}

function moveFailure(item, move) {
  if (!item.video || item.unavailable) return '시청 불가 영상은 이동할 수 없습니다.';
  const attempt = move.attempts.get(item.video);
  if (attempt === 'ambiguous') return '같은 이름의 대상 재생목록이 여러 개 있습니다.';
  if (attempt !== 'attempted' && attempt !== 'present') return '대상 재생목록에 저장할 수 없습니다.';
  return move.verified.has(item.video) ? '' : '대상 재생목록에서 영상을 확인하지 못했습니다. 원래 목록에 남겨두었습니다.';
}

function addResult(item, site, success, detail) {
  if (success) successCount++;
  else failureCount++;
  const row = document.createElement('li');
  const indicator = document.createElement('span');
  indicator.className = 'result-status';
  indicator.dataset.success = String(success);
  indicator.textContent = success ? '완료' : '실패';
  const note = document.createElement('div');
  note.className = 'result-detail';
  note.textContent = detail;
  row.append(indicator, ` · ${platforms[site].name} · `, item.url ? linkToItem(item, itemTitle(item)) : itemTitle(item), note);
  $('results').append(row);
  $('result-summary').textContent = `완료 ${successCount}개 · 실패 ${failureCount}개`;
}

async function runBatch(context) {
  if (busy) return;
  setBusy(true);
  running = true;
  let workTabId;
  let playlistTab;
  const isPlaylist = context.platform === 'youtube-playlist';
  const usePlaylist = (item) => isPlaylist || Boolean(item.unavailable || item.duplicate);
  const native = context.queue.filter(usePlaylist).reverse()
    .sort((a, b) => (b.position ?? 0) - (a.position ?? 0));
  const ordinary = context.queue.filter((item) => !usePlaylist(item));
  const queue = [...native, ...ordinary];
  let recordingFailed = false;
  try {
    await navigator.locks.request('social-saves-cleanup', { ifAvailable: true }, async (lock) => {
      if (!lock) throw new Error('다른 정리 화면에서 작업 중입니다. 완료 후 다시 시도하세요.');
      const latest = await chrome.tabs.get(context.source.id);
      if (sourceKey(context.platform, latest.url) !== context.source.key) {
        throw new Error('원본 목록 탭이 바뀌었습니다. 목록을 다시 불러와 주세요.');
      }
      if (native.length) {
        playlistTab = await sourceTabContext(latest);
        await showSourceTab(playlistTab);
      }
      if (ordinary.length || context.destination) {
        const workTab = await chrome.tabs.create({ url: 'about:blank', active: false });
        workTabId = workTab.id;
        await chrome.tabs.update(workTabId, { muted: true });
      }
      successCount = 0;
      failureCount = 0;
      $('results').replaceChildren();
      $('result-summary').textContent = '';
      $('results-panel').hidden = false;
      let move;
      if (context.destination) {
        try {
          move = await preparePlaylistMove(context, workTabId);
        } finally {
          await showSourceTab(playlistTab).catch(() => {});
        }
      }
      const excluded = completedBySource.get(context.source.key) || new Set();
      completedBySource.set(context.source.key, excluded);
      for (const [index, item] of queue.entries()) {
        status(`선택한 항목을 정리하는 중입니다. ${index + 1} / ${queue.length}`);
        try {
          if (move) {
            const issue = moveFailure(item, move);
            if (issue) throw new Error(issue);
          }
          const nativeRemoval = usePlaylist(item);
          let detail = nativeRemoval
            ? await processPlaylistItem(context.source, item)
            : await processItem(workTabId, item, context.platform);
          if (move) detail = `‘${context.destination.label}’에서 확인한 뒤 원래 목록에서 제거했습니다.`;
          if (detail !== '이미 해제된 상태입니다.') {
            await saveHistory({
              site: platforms[context.platform].name, action: move ? '재생목록 이동' : platforms[context.platform].action,
              title: itemTitle(item), url: item.url, source: context.source.label, destination: context.destination?.label,
            }).catch(() => { recordingFailed = true; });
          }
          if (!nativeRemoval) excluded.add(item.video || item.id);
          items.delete(item.id);
          selected.delete(item.id);
          addResult(item, context.platform, true, detail);
        } catch (error) {
          const prefix = move?.verified.has(item.video) && !moveFailure(item, move) ? '대상에서는 확인됐습니다. ' : '';
          addResult(item, context.platform, false, prefix + (error.message || '항목을 정리하지 못했습니다.'));
        }
      }
      renderItems();
      status(recordingFailed ? '정리 작업이 끝났습니다. 일부 정리 내역을 저장하지 못했습니다.' : '정리 작업이 끝났습니다.', recordingFailed);
    });
  } catch (error) {
    status(error.message || '정리 작업을 시작하지 못했습니다.', true);
  } finally {
    if (workTabId !== undefined) await chrome.tabs.remove(workTabId).catch(() => {});
    if (playlistTab) await returnToDashboard(playlistTab);
    running = false;
    setBusy(false);
  }
}

function renderBookmarks() {
  const result = $('bookmark-results');
  const fragment = document.createDocumentFragment();
  for (const [index, [url, entries]] of bookmarks.entries()) {
    const row = document.createElement('li');
    const link = linkToItem({ url }, url);
    const locations = document.createElement('ul');
    for (const entry of entries) {
      const line = document.createElement('li');
      const label = document.createElement('label');
      const radio = document.createElement('input');
      radio.type = 'radio';
      radio.name = `keep-bookmark-${index}`;
      radio.value = entry.id;
      const text = document.createElement('span');
      const folder = document.createElement('span');
      folder.className = 'bookmark-folder';
      folder.textContent = [entry.folder, entry.readOnly ? '관리되는 북마크' : ''].filter(Boolean).join(' · ');
      text.append(entry.title, document.createElement('br'), folder);
      label.append(radio, text);
      line.append(label);
      locations.append(line);
    }
    row.append(link, locations);
    fragment.append(row);
  }
  result.replaceChildren(fragment);
  $('review-bookmarks').hidden = !bookmarks.length;
  $('review-bookmarks').disabled = true;
}

function chosenBookmarkGroups() {
  return bookmarks.flatMap(([url, entries], index) => {
    const keepId = $('bookmark-results').querySelector(`input[name="keep-bookmark-${index}"]:checked`)?.value;
    const keep = entries.find((entry) => entry.id === keepId);
    const remove = entries.filter((entry) => entry !== keep && !entry.readOnly);
    return keep && remove.length ? [{ url, keep, remove }] : [];
  });
}

function reviewBookmarkRemoval() {
  if (busy) return;
  bookmarkPlan = chosenBookmarkGroups();
  if (!bookmarkPlan.length) return;
  const count = bookmarkPlan.reduce((sum, group) => sum + group.remove.length, 0);
  $('bookmark-confirm-message').textContent = `선택한 북마크를 남기고 아래 ${count}개를 삭제합니다.`;
  $('bookmark-confirm-items').replaceChildren(...bookmarkPlan.flatMap((group) => group.remove.map((entry) => {
    const row = document.createElement('li');
    row.textContent = [entry.title, entry.folder].filter(Boolean).join(' · ');
    return row;
  })));
  bookmarkDialog.showModal();
}

async function removeDuplicateBookmarks(plan) {
  if (busy || !plan.length) return;
  setBusy(true);
  running = true;
  const message = $('bookmark-status');
  let removed = 0;
  let failed = 0;
  let recordingFailed = false;
  try {
    await navigator.locks.request('social-saves-cleanup', { ifAvailable: true }, async (lock) => {
      if (!lock) throw new Error('다른 정리 화면에서 작업 중입니다. 완료 후 다시 시도하세요.');
      for (const { url, keep, remove } of plan) {
        for (const entry of remove) {
          try {
            const current = await chrome.bookmarks.get([keep.id, entry.id]);
            const stillKept = current.find((node) => node.id === keep.id);
            const target = current.find((node) => node.id === entry.id);
            if (!sameBookmark(stillKept, keep, url) || !sameBookmark(target, entry, url) || target.unmodifiable) {
              throw new Error('선택한 북마크가 변경되었습니다.');
            }
            await chrome.bookmarks.remove(target.id);
            removed++;
            await saveHistory({ site: 'Chrome', action: '중복 북마크 삭제', title: entry.title, url, source: entry.folder })
              .catch(() => { recordingFailed = true; });
          } catch {
            failed++;
          }
        }
      }
      bookmarks = findDuplicateBookmarks(await chrome.bookmarks.getTree());
      message.textContent = `삭제 ${removed}개 · 삭제하지 못한 항목 ${failed}개.` +
        (recordingFailed ? ' 일부 정리 내역을 저장하지 못했습니다.' : '');
    });
  } catch (error) {
    message.textContent = removed
      ? `${removed}개를 삭제했습니다. 중복 링크를 다시 찾아 결과를 확인하세요.`
      : error.message;
  } finally {
    renderBookmarks();
    running = false;
    setBusy(false);
  }
}

async function showDuplicateBookmarks() {
  if (busy) return;
  setBusy(true);
  const message = $('bookmark-status');
  bookmarks = [];
  renderBookmarks();
  message.textContent = '중복 링크를 찾는 중입니다.';
  try {
    if (!await chrome.permissions.request({ permissions: ['bookmarks'] })) {
      message.textContent = '찾으려면 Chrome의 북마크 접근 권한을 허용하세요.';
      return;
    }
    bookmarks = findDuplicateBookmarks(await chrome.bookmarks.getTree());
    renderBookmarks();
    message.textContent = bookmarks.length
      ? `중복 주소 ${bookmarks.length}개를 찾았습니다. 각 주소에서 남길 북마크를 선택하세요.`
      : '같은 주소로 저장된 북마크가 없습니다.';
  } catch {
    message.textContent = '북마크를 읽지 못했습니다. Chrome에서 권한을 확인하세요.';
  } finally {
    setBusy(false);
  }
}

window.addEventListener('beforeunload', (event) => {
  if (!running) return;
  event.preventDefault();
  event.returnValue = '';
});

for (const button of platformButtons) {
  button.addEventListener('click', () => {
    if (!busy && platform !== button.dataset.platform) void choosePlatform(button.dataset.platform);
  });
}
sourceSelect.addEventListener('change', () => {
  resetList();
  resetCollections();
  status('선택한 탭에서 목록을 불러올 수 있습니다.');
});
$('refresh-tabs').addEventListener('click', refreshTabs);
$('load-form').addEventListener('submit', (event) => {
  event.preventDefault();
  void loadList();
});
$('load-collections').addEventListener('click', loadCollections);
collectionSelect.addEventListener('change', () => {
  resetList();
  status('목록 불러오기를 눌러 선택한 컬렉션을 확인하세요.');
});
$('find-bookmarks').addEventListener('click', showDuplicateBookmarks);
$('bookmark-results').addEventListener('change', () => {
  $('review-bookmarks').disabled = busy || !chosenBookmarkGroups().length;
});
$('review-bookmarks').addEventListener('click', reviewBookmarkRemoval);
bookmarkDialog.querySelector('form').addEventListener('submit', (event) => {
  if (event.submitter?.value === 'remove') void removeDuplicateBookmarks(bookmarkPlan);
});
$('export-history').addEventListener('click', exportHistory);
$('review').addEventListener('click', showReview);
$('move').addEventListener('click', showMoveReview);
destinationSelect.addEventListener('change', () => {
  $('run').disabled = !destinationSelect.value;
});
dialog.querySelector('form').addEventListener('submit', (event) => {
  if (event.submitter !== $('run') || !reviewContext) return;
  const destination = reviewContext.targets?.get(destinationSelect.value);
  if (!reviewContext.targets || destination) void runBatch({ ...reviewContext, destination });
});
itemSearch.addEventListener('input', applyItemFilters);
itemFilter.addEventListener('change', applyItemFilters);
cleanupButton.addEventListener('click', () => {
  selected.clear();
  for (const checkbox of $('items').querySelectorAll('input')) {
    checkbox.checked = Boolean(items.get(checkbox.value)?.cleanup);
    if (checkbox.checked) selected.add(checkbox.value);
  }
  syncControls();
});
groupItems.addEventListener('click', () => {
  grouped = !grouped;
  groupItems.setAttribute('aria-pressed', String(grouped));
  arrangeItems();
});
$('items').addEventListener('change', (event) => {
  const checkbox = event.target;
  if (checkbox.checked) selected.add(checkbox.value);
  else selected.delete(checkbox.value);
  syncControls();
});
selectAll.addEventListener('change', () => {
  for (const checkbox of $('items').querySelectorAll('.item-row:not([hidden]) input')) {
    checkbox.checked = selectAll.checked;
    if (checkbox.checked) selected.add(checkbox.value);
    else selected.delete(checkbox.value);
  }
  syncControls();
});

void choosePlatform(platform);
