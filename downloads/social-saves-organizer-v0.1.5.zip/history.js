const prefix = 'cleanup-history:';

export async function saveHistory(entry) {
  const key = prefix + crypto.randomUUID();
  await chrome.storage.local.set({ [key]: { ...entry, at: new Date().toISOString() } });
}

export async function readHistory() {
  const storage = await chrome.storage.local.get(null);
  return Object.entries(storage).filter(([key]) => key.startsWith(prefix)).map(([, entry]) => entry)
    .sort((a, b) => b.at.localeCompare(a.at));
}

export function historyCsv(entries) {
  const field = (value) => {
    const text = String(value ?? '');
    const safe = /^(?:\s*[=+@-]|[\t\r\n])/.test(text) ? "'" + text : text;
    return '"' + safe.replaceAll('"', '""') + '"';
  };
  const rows = [
    ['일시(UTC)', '동작', '서비스', '항목', '주소', '원본 목록', '대상 목록'],
    ...entries.map((entry) => [entry.at, entry.action, entry.site, entry.title, entry.url, entry.source, entry.destination]),
  ];
  return '\uFEFF' + rows.map((row) => row.map(field).join(',')).join('\r\n') + '\r\n';
}
